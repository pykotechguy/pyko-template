<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-08-04 17:16:59 --> Severity: Notice  --> Use of undefined constant SYSTEM_TIME_REFERENCE - assumed 'SYSTEM_TIME_REFERENCE' C:\xampp\htdocs\Newprototype\application\config\config.php 339
DEBUG - 2013-08-04 17:16:59 --> Config Class Initialized
DEBUG - 2013-08-04 17:16:59 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:16:59 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:16:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:16:59 --> URI Class Initialized
DEBUG - 2013-08-04 17:16:59 --> Router Class Initialized
DEBUG - 2013-08-04 17:16:59 --> No URI present. Default controller set.
DEBUG - 2013-08-04 17:16:59 --> Output Class Initialized
DEBUG - 2013-08-04 17:16:59 --> Security Class Initialized
DEBUG - 2013-08-04 17:16:59 --> Input Class Initialized
DEBUG - 2013-08-04 17:16:59 --> CRSF cookie Set
DEBUG - 2013-08-04 17:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:16:59 --> Language Class Initialized
DEBUG - 2013-08-04 17:19:58 --> Config Class Initialized
DEBUG - 2013-08-04 17:19:58 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:19:58 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:19:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:19:58 --> URI Class Initialized
DEBUG - 2013-08-04 17:19:58 --> Router Class Initialized
DEBUG - 2013-08-04 17:19:58 --> No URI present. Default controller set.
DEBUG - 2013-08-04 17:19:58 --> Output Class Initialized
DEBUG - 2013-08-04 17:19:58 --> Security Class Initialized
DEBUG - 2013-08-04 17:19:58 --> Input Class Initialized
DEBUG - 2013-08-04 17:19:58 --> XSS Filtering completed
DEBUG - 2013-08-04 17:19:58 --> CRSF cookie Set
DEBUG - 2013-08-04 17:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:19:58 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:46 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:46 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:46 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:46 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:46 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:46 --> No URI present. Default controller set.
DEBUG - 2013-08-04 17:20:46 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:46 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:46 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:46 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:46 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:46 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:50 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:50 --> No URI present. Default controller set.
DEBUG - 2013-08-04 17:20:50 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:50 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:50 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:50 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:50 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:50 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:51 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:52 --> A session cookie was not found.
DEBUG - 2013-08-04 17:20:52 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:52 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:52 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:52 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:52 --> File loaded: application/views/login.php
DEBUG - 2013-08-04 17:20:52 --> Final output sent to browser
DEBUG - 2013-08-04 17:20:52 --> Total execution time: 0.1184
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:52 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:52 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:52 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:52 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:52 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:52 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:52 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:52 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:52 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:52 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:52 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:52 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/images
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:53 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:53 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:53 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:20:53 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:53 --> Session routines successfully run
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:53 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:53 --> 404 Page Not Found --> main/images
DEBUG - 2013-08-04 17:20:53 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:53 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:53 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:53 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:54 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:54 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:54 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:54 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:54 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:54 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:54 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:54 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:54 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:54 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:54 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:54 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:54 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:54 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:54 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:54 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:54 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:54 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:54 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:54 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:54 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:54 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:54 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:54 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:54 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:54 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:54 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:54 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:54 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:54 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:54 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:54 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:54 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:54 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:54 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:54 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:54 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:54 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:54 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:55 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:55 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:55 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:55 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:55 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:55 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:55 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:55 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:55 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:55 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:55 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:55 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:55 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:55 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:20:55 --> Config Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:20:55 --> URI Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Router Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Output Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Security Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Input Class Initialized
DEBUG - 2013-08-04 17:20:55 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:55 --> XSS Filtering completed
DEBUG - 2013-08-04 17:20:55 --> CRSF cookie Set
DEBUG - 2013-08-04 17:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:20:55 --> Language Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Loader Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:20:55 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Session Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:20:55 --> Session routines successfully run
DEBUG - 2013-08-04 17:20:55 --> Controller Class Initialized
DEBUG - 2013-08-04 17:20:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:20:55 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:26 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:26 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:26 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:26 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:26 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:26 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:26 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:26 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:26 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:26 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> File loaded: application/views/login.php
DEBUG - 2013-08-04 17:26:27 --> Final output sent to browser
DEBUG - 2013-08-04 17:26:27 --> Total execution time: 0.1559
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Session routines successfully run
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:27 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:27 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:27 --> UTF-8 Support Enabled
ERROR - 2013-08-04 17:26:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:28 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:28 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:28 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:28 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:28 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:28 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:28 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:28 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:28 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:28 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:28 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:28 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:28 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:28 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:28 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:28 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:28 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:28 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:28 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:28 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:28 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:28 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:28 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:28 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:28 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:28 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:28 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:28 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:28 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:28 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:28 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:28 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:28 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:28 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:28 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:28 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:28 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:28 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:28 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:28 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:28 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:29 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:29 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:29 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:29 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:29 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:29 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:29 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:29 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:29 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:29 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:29 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:29 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:29 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:29 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:29 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:29 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:29 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:29 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:29 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:29 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:29 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:29 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:29 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:29 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:29 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:29 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:29 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:29 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:29 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:29 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:29 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:29 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:29 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:29 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:29 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:29 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:29 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:33 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:33 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:33 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:33 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:33 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:33 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:33 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:33 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:33 --> File loaded: application/views/login.php
DEBUG - 2013-08-04 17:26:33 --> Final output sent to browser
DEBUG - 2013-08-04 17:26:33 --> Total execution time: 0.1717
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:33 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:34 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:34 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:34 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:34 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:34 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:34 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:34 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:34 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:34 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:35 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:35 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:35 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:35 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:35 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:35 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:35 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:35 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:35 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:35 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:35 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:35 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:35 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:35 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:35 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:35 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:35 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:35 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:35 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:35 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:35 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:35 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:35 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:35 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:35 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:35 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:35 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:35 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:35 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:35 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:35 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:36 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:36 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:36 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:36 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:36 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:36 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:36 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:36 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:36 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:36 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:36 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:36 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:36 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:36 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:36 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:36 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:36 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:36 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:36 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-04 17:26:36 --> Config Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Hooks Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Utf8 Class Initialized
DEBUG - 2013-08-04 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-04 17:26:36 --> URI Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Router Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Output Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Security Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Input Class Initialized
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> XSS Filtering completed
DEBUG - 2013-08-04 17:26:36 --> CRSF cookie Set
DEBUG - 2013-08-04 17:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-04 17:26:36 --> Language Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Loader Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: url_helper
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: form_helper
DEBUG - 2013-08-04 17:26:36 --> Database Driver Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Helper loaded: string_helper
DEBUG - 2013-08-04 17:26:36 --> Session routines successfully run
DEBUG - 2013-08-04 17:26:36 --> Controller Class Initialized
DEBUG - 2013-08-04 17:26:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-04 17:26:36 --> 404 Page Not Found --> main/js

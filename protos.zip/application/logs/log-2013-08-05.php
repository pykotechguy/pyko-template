<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-08-05 05:24:22 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:22 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:22 --> No URI present. Default controller set.
DEBUG - 2013-08-05 05:24:22 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:22 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:22 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:22 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:22 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:23 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:24 --> A session cookie was not found.
DEBUG - 2013-08-05 05:24:24 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:24 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:24:24 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:24 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:24 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:24 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:24 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:24 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:24:24 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 05:24:24 --> Final output sent to browser
DEBUG - 2013-08-05 05:24:24 --> Total execution time: 0.1806
DEBUG - 2013-08-05 05:24:24 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:24 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:24 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:24 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:24 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:24 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:24 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:24 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:24 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:24 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:24 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:24 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:24 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:25 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:25 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:25 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:25 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:25 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:25 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:25 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:25 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:25 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:25 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:25 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:25 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:25 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:25 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:25 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:25 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:25 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:25 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:25 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:25 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:26 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: form_helper
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Database Driver Class Initialized
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:26 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:26 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:26 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:24:26 --> Config Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:24:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:24:26 --> URI Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Router Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Output Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Security Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Input Class Initialized
DEBUG - 2013-08-05 05:24:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:24:26 --> CRSF cookie Set
DEBUG - 2013-08-05 05:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:24:26 --> Language Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Loader Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:24:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:24:26 --> Session routines successfully run
DEBUG - 2013-08-05 05:24:26 --> Controller Class Initialized
DEBUG - 2013-08-05 05:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:24:26 --> 404 Page Not Found --> main/images
DEBUG - 2013-08-05 05:32:14 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 05:32:15 --> Final output sent to browser
DEBUG - 2013-08-05 05:32:15 --> Total execution time: 0.1423
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Config Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> URI Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Router Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Output Class Initialized
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Security Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Input Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> XSS Filtering completed
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> CRSF cookie Set
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Language Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:15 --> Session routines successfully run
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Loader Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: url_helper
ERROR - 2013-08-05 05:32:15 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:32:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:32:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:32:15 --> Session Class Initialized
DEBUG - 2013-08-05 05:32:16 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:32:16 --> Session routines successfully run
DEBUG - 2013-08-05 05:32:16 --> Controller Class Initialized
DEBUG - 2013-08-05 05:32:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:32:16 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:49 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:49 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:49 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:49 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:49 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:49 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:49 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:49 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:49 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:49 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:50 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:50 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:50 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 05:33:50 --> Final output sent to browser
DEBUG - 2013-08-05 05:33:50 --> Total execution time: 0.2792
DEBUG - 2013-08-05 05:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:50 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:51 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:51 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:51 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: string_helper
ERROR - 2013-08-05 05:33:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:51 --> Session routines successfully run
ERROR - 2013-08-05 05:33:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:33:51 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:33:51 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:33:51 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:33:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:33:52 --> Session routines successfully run
ERROR - 2013-08-05 05:33:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:33:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:33:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:52 --> Controller Class Initialized
ERROR - 2013-08-05 05:33:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:33:52 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:33:53 --> Config Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:33:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:33:53 --> URI Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Router Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Output Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Security Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Input Class Initialized
DEBUG - 2013-08-05 05:33:53 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:53 --> XSS Filtering completed
DEBUG - 2013-08-05 05:33:53 --> CRSF cookie Set
DEBUG - 2013-08-05 05:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:33:53 --> Language Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Loader Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:33:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:33:53 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Session Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:33:53 --> Session routines successfully run
DEBUG - 2013-08-05 05:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 05:33:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:33:53 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:08 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:08 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:08 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:08 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:08 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:08 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:08 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:09 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 05:36:09 --> Final output sent to browser
DEBUG - 2013-08-05 05:36:09 --> Total execution time: 0.2372
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
ERROR - 2013-08-05 05:36:09 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:09 --> Controller Class Initialized
ERROR - 2013-08-05 05:36:09 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:36:09 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:36:09 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
ERROR - 2013-08-05 05:36:09 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:36:09 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:09 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:10 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:10 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:10 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:10 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Session Class Initialized
ERROR - 2013-08-05 05:36:10 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:10 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:10 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:10 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:10 --> Session routines successfully run
ERROR - 2013-08-05 05:36:10 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:10 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Session routines successfully run
ERROR - 2013-08-05 05:36:10 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:10 --> Controller Class Initialized
ERROR - 2013-08-05 05:36:10 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:36:10 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:10 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:10 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:36:10 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:57 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 05:36:57 --> Final output sent to browser
DEBUG - 2013-08-05 05:36:57 --> Total execution time: 0.1939
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Database Driver Class Initialized
ERROR - 2013-08-05 05:36:57 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
ERROR - 2013-08-05 05:36:57 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:36:57 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
ERROR - 2013-08-05 05:36:57 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
ERROR - 2013-08-05 05:36:57 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
ERROR - 2013-08-05 05:36:57 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:57 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Input Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:58 --> Language Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:58 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:58 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:58 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:58 --> XSS Filtering completed
DEBUG - 2013-08-05 05:36:58 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:58 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:58 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:58 --> CRSF cookie Set
DEBUG - 2013-08-05 05:36:58 --> Controller Class Initialized
ERROR - 2013-08-05 05:36:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:36:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:58 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:58 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:58 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Language Class Initialized
ERROR - 2013-08-05 05:36:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:58 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:58 --> Session routines successfully run
ERROR - 2013-08-05 05:36:58 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 05:36:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:58 --> Loader Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: url_helper
ERROR - 2013-08-05 05:36:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:36:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:36:58 --> Session routines successfully run
DEBUG - 2013-08-05 05:36:58 --> Controller Class Initialized
DEBUG - 2013-08-05 05:36:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:36:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:37:06 --> Config Class Initialized
DEBUG - 2013-08-05 05:37:06 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:37:06 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:37:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:37:06 --> URI Class Initialized
DEBUG - 2013-08-05 05:37:06 --> Router Class Initialized
ERROR - 2013-08-05 05:37:06 --> 404 Page Not Found --> dashboard
DEBUG - 2013-08-05 05:39:24 --> Config Class Initialized
DEBUG - 2013-08-05 05:39:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:39:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:39:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:39:24 --> URI Class Initialized
DEBUG - 2013-08-05 05:39:24 --> Router Class Initialized
ERROR - 2013-08-05 05:39:24 --> 404 Page Not Found --> dashboard
DEBUG - 2013-08-05 05:39:57 --> Config Class Initialized
DEBUG - 2013-08-05 05:39:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:39:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:39:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:39:57 --> URI Class Initialized
DEBUG - 2013-08-05 05:39:57 --> Router Class Initialized
DEBUG - 2013-08-05 05:39:57 --> Output Class Initialized
DEBUG - 2013-08-05 05:39:57 --> Security Class Initialized
DEBUG - 2013-08-05 05:39:57 --> Input Class Initialized
DEBUG - 2013-08-05 05:39:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:39:57 --> XSS Filtering completed
DEBUG - 2013-08-05 05:39:57 --> CRSF cookie Set
DEBUG - 2013-08-05 05:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:39:57 --> Language Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:26 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Output Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Security Class Initialized
DEBUG - 2013-08-05 05:40:26 --> Input Class Initialized
DEBUG - 2013-08-05 05:40:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:40:26 --> XSS Filtering completed
DEBUG - 2013-08-05 05:40:26 --> CRSF cookie Set
DEBUG - 2013-08-05 05:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:40:26 --> Language Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:32 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Output Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Security Class Initialized
DEBUG - 2013-08-05 05:40:32 --> Input Class Initialized
DEBUG - 2013-08-05 05:40:32 --> XSS Filtering completed
DEBUG - 2013-08-05 05:40:32 --> XSS Filtering completed
DEBUG - 2013-08-05 05:40:32 --> CRSF cookie Set
DEBUG - 2013-08-05 05:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:40:32 --> Language Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Output Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Security Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Input Class Initialized
DEBUG - 2013-08-05 05:40:39 --> XSS Filtering completed
DEBUG - 2013-08-05 05:40:39 --> XSS Filtering completed
DEBUG - 2013-08-05 05:40:39 --> CRSF cookie Set
DEBUG - 2013-08-05 05:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:40:39 --> Language Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Loader Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:40:39 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:40:39 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Session Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:40:39 --> Session routines successfully run
DEBUG - 2013-08-05 05:40:39 --> Controller Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:40:39 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 05:40:39 --> Final output sent to browser
DEBUG - 2013-08-05 05:40:39 --> Total execution time: 0.2550
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:39 --> URI Class Initialized
ERROR - 2013-08-05 05:40:39 --> 404 Page Not Found --> js
ERROR - 2013-08-05 05:40:39 --> 404 Page Not Found --> dllb.png
ERROR - 2013-08-05 05:40:39 --> 404 Page Not Found --> javascript.js
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
ERROR - 2013-08-05 05:40:39 --> 404 Page Not Found --> js
DEBUG - 2013-08-05 05:40:39 --> Router Class Initialized
ERROR - 2013-08-05 05:40:39 --> 404 Page Not Found --> dashboard.css
ERROR - 2013-08-05 05:40:39 --> 404 Page Not Found --> d11b.png
DEBUG - 2013-08-05 05:40:40 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Config Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:40:40 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:40 --> URI Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Router Class Initialized
DEBUG - 2013-08-05 05:40:40 --> Router Class Initialized
ERROR - 2013-08-05 05:40:40 --> 404 Page Not Found --> d11b.png
ERROR - 2013-08-05 05:40:40 --> 404 Page Not Found --> dllb.png
DEBUG - 2013-08-05 05:44:29 --> Config Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:44:29 --> URI Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Router Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Output Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Security Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Input Class Initialized
DEBUG - 2013-08-05 05:44:29 --> XSS Filtering completed
DEBUG - 2013-08-05 05:44:29 --> XSS Filtering completed
DEBUG - 2013-08-05 05:44:29 --> CRSF cookie Set
DEBUG - 2013-08-05 05:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:44:29 --> Language Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Loader Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:44:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:44:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Session Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:44:29 --> Session routines successfully run
DEBUG - 2013-08-05 05:44:29 --> Controller Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:44:29 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 05:44:29 --> Final output sent to browser
DEBUG - 2013-08-05 05:44:29 --> Total execution time: 0.2155
DEBUG - 2013-08-05 05:44:29 --> Config Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:44:29 --> URI Class Initialized
DEBUG - 2013-08-05 05:44:29 --> Router Class Initialized
ERROR - 2013-08-05 05:44:29 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 05:45:33 --> Config Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:45:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:45:33 --> URI Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Router Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Output Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Security Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Input Class Initialized
DEBUG - 2013-08-05 05:45:33 --> XSS Filtering completed
DEBUG - 2013-08-05 05:45:33 --> XSS Filtering completed
DEBUG - 2013-08-05 05:45:33 --> CRSF cookie Set
DEBUG - 2013-08-05 05:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:45:33 --> Language Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Loader Class Initialized
DEBUG - 2013-08-05 05:45:33 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:45:33 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:45:34 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:45:34 --> Session Class Initialized
DEBUG - 2013-08-05 05:45:34 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:45:34 --> Session routines successfully run
DEBUG - 2013-08-05 05:45:34 --> Controller Class Initialized
DEBUG - 2013-08-05 05:45:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:45:34 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 05:45:34 --> Final output sent to browser
DEBUG - 2013-08-05 05:45:34 --> Total execution time: 0.2067
DEBUG - 2013-08-05 05:45:34 --> Config Class Initialized
DEBUG - 2013-08-05 05:45:34 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:45:34 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:45:34 --> URI Class Initialized
DEBUG - 2013-08-05 05:45:34 --> Router Class Initialized
ERROR - 2013-08-05 05:45:34 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 05:46:53 --> Config Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:46:53 --> URI Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Router Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Output Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Security Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Input Class Initialized
DEBUG - 2013-08-05 05:46:53 --> XSS Filtering completed
DEBUG - 2013-08-05 05:46:53 --> XSS Filtering completed
DEBUG - 2013-08-05 05:46:53 --> CRSF cookie Set
DEBUG - 2013-08-05 05:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:46:53 --> Language Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Loader Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:46:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:46:53 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Session Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:46:53 --> Session routines successfully run
DEBUG - 2013-08-05 05:46:53 --> Controller Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:46:53 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 05:46:53 --> Final output sent to browser
DEBUG - 2013-08-05 05:46:53 --> Total execution time: 0.2196
DEBUG - 2013-08-05 05:46:53 --> Config Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:46:53 --> URI Class Initialized
DEBUG - 2013-08-05 05:46:53 --> Router Class Initialized
ERROR - 2013-08-05 05:46:53 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 05:48:38 --> Config Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:48:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:48:38 --> URI Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Router Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Output Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Security Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Input Class Initialized
DEBUG - 2013-08-05 05:48:38 --> XSS Filtering completed
DEBUG - 2013-08-05 05:48:38 --> XSS Filtering completed
DEBUG - 2013-08-05 05:48:38 --> CRSF cookie Set
DEBUG - 2013-08-05 05:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:48:38 --> Language Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Loader Class Initialized
DEBUG - 2013-08-05 05:48:38 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:48:38 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:48:38 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:48:39 --> Session Class Initialized
DEBUG - 2013-08-05 05:48:39 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:48:39 --> Session routines successfully run
DEBUG - 2013-08-05 05:48:39 --> Controller Class Initialized
DEBUG - 2013-08-05 05:48:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:48:39 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:50:07 --> Config Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:50:07 --> URI Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Router Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Output Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Security Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Input Class Initialized
DEBUG - 2013-08-05 05:50:07 --> XSS Filtering completed
DEBUG - 2013-08-05 05:50:07 --> XSS Filtering completed
DEBUG - 2013-08-05 05:50:07 --> CRSF cookie Set
DEBUG - 2013-08-05 05:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:50:07 --> Language Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Loader Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:50:07 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:50:07 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Session Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:50:07 --> Session routines successfully run
DEBUG - 2013-08-05 05:50:07 --> Controller Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:50:07 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 05:50:07 --> Final output sent to browser
DEBUG - 2013-08-05 05:50:07 --> Total execution time: 0.2049
DEBUG - 2013-08-05 05:50:07 --> Config Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:50:07 --> URI Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Router Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Output Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Security Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Input Class Initialized
DEBUG - 2013-08-05 05:50:07 --> XSS Filtering completed
DEBUG - 2013-08-05 05:50:07 --> XSS Filtering completed
DEBUG - 2013-08-05 05:50:07 --> CRSF cookie Set
DEBUG - 2013-08-05 05:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:50:07 --> Language Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Loader Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:50:07 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:50:07 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Session Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:50:07 --> Session routines successfully run
DEBUG - 2013-08-05 05:50:07 --> Controller Class Initialized
DEBUG - 2013-08-05 05:50:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 05:50:07 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 05:50:23 --> Config Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:50:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:50:23 --> URI Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Router Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Output Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Security Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Input Class Initialized
DEBUG - 2013-08-05 05:50:23 --> XSS Filtering completed
DEBUG - 2013-08-05 05:50:23 --> XSS Filtering completed
DEBUG - 2013-08-05 05:50:23 --> CRSF cookie Set
DEBUG - 2013-08-05 05:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 05:50:23 --> Language Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Loader Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Helper loaded: url_helper
DEBUG - 2013-08-05 05:50:23 --> Helper loaded: form_helper
DEBUG - 2013-08-05 05:50:23 --> Database Driver Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Session Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Helper loaded: string_helper
DEBUG - 2013-08-05 05:50:23 --> Session routines successfully run
DEBUG - 2013-08-05 05:50:23 --> Controller Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 05:50:23 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 05:50:23 --> Final output sent to browser
DEBUG - 2013-08-05 05:50:23 --> Total execution time: 0.2159
DEBUG - 2013-08-05 05:50:23 --> Config Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 05:50:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 05:50:23 --> URI Class Initialized
DEBUG - 2013-08-05 05:50:23 --> Router Class Initialized
ERROR - 2013-08-05 05:50:23 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 08:50:02 --> Config Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 08:50:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 08:50:02 --> URI Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Router Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Output Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Security Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Input Class Initialized
DEBUG - 2013-08-05 08:50:02 --> CRSF cookie Set
DEBUG - 2013-08-05 08:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 08:50:02 --> Language Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Loader Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 08:50:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 08:50:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Session Class Initialized
DEBUG - 2013-08-05 08:50:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 08:50:02 --> A session cookie was not found.
DEBUG - 2013-08-05 08:50:02 --> Session routines successfully run
DEBUG - 2013-08-05 08:50:03 --> Controller Class Initialized
DEBUG - 2013-08-05 08:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 08:50:03 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 08:50:03 --> Final output sent to browser
DEBUG - 2013-08-05 08:50:03 --> Total execution time: 0.9112
DEBUG - 2013-08-05 08:50:03 --> Config Class Initialized
DEBUG - 2013-08-05 08:50:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 08:50:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 08:50:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 08:50:03 --> URI Class Initialized
DEBUG - 2013-08-05 08:50:03 --> Router Class Initialized
ERROR - 2013-08-05 08:50:03 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> No URI present. Default controller set.
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:50 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:50 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:50 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:50 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:50 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:50 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:50 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 09:24:50 --> Final output sent to browser
DEBUG - 2013-08-05 09:24:50 --> Total execution time: 0.2090
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:50 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Hooks Class Initialized
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:51 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:51 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:51 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:51 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:51 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:51 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:51 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:51 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:51 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:51 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:51 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 09:24:51 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 09:24:54 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:54 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Router Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Output Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Security Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Input Class Initialized
DEBUG - 2013-08-05 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:54 --> XSS Filtering completed
DEBUG - 2013-08-05 09:24:54 --> CRSF cookie Set
DEBUG - 2013-08-05 09:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 09:24:54 --> Language Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Loader Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Helper loaded: url_helper
DEBUG - 2013-08-05 09:24:54 --> Helper loaded: form_helper
DEBUG - 2013-08-05 09:24:54 --> Database Driver Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Session Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Helper loaded: string_helper
DEBUG - 2013-08-05 09:24:54 --> Session routines successfully run
DEBUG - 2013-08-05 09:24:54 --> Controller Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 09:24:54 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 09:24:54 --> Final output sent to browser
DEBUG - 2013-08-05 09:24:54 --> Total execution time: 0.2398
DEBUG - 2013-08-05 09:24:54 --> Config Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Hooks Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Utf8 Class Initialized
DEBUG - 2013-08-05 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 09:24:54 --> URI Class Initialized
DEBUG - 2013-08-05 09:24:54 --> Router Class Initialized
ERROR - 2013-08-05 09:24:54 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:16:18 --> Config Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:16:18 --> URI Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Router Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Output Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Security Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Input Class Initialized
DEBUG - 2013-08-05 10:16:18 --> CRSF cookie Set
DEBUG - 2013-08-05 10:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:16:18 --> Language Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Loader Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:16:18 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:16:18 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Session Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:16:18 --> A session cookie was not found.
DEBUG - 2013-08-05 10:16:18 --> Session routines successfully run
DEBUG - 2013-08-05 10:16:18 --> Controller Class Initialized
DEBUG - 2013-08-05 10:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:16:18 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:16:18 --> Final output sent to browser
DEBUG - 2013-08-05 10:16:18 --> Total execution time: 0.2191
DEBUG - 2013-08-05 10:16:19 --> Config Class Initialized
DEBUG - 2013-08-05 10:16:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:16:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:16:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:16:19 --> URI Class Initialized
DEBUG - 2013-08-05 10:16:19 --> Router Class Initialized
ERROR - 2013-08-05 10:16:19 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:17:08 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:08 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:08 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:08 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:08 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:08 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:08 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:08 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:08 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:08 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:08 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:08 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:08 --> Total execution time: 0.2577
DEBUG - 2013-08-05 10:17:09 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:09 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:09 --> Router Class Initialized
ERROR - 2013-08-05 10:17:09 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:17:14 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:14 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:14 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:14 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:14 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:14 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:14 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:14 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:14 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:14 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:14 --> Total execution time: 0.2579
DEBUG - 2013-08-05 10:17:23 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:23 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:23 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:23 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:23 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:23 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:23 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:23 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:23 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:23 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:23 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:23 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:23 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Total execution time: 0.2375
DEBUG - 2013-08-05 10:17:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:23 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:23 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:23 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:23 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:23 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:23 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:23 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:23 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:23 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:23 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:23 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:23 --> Total execution time: 0.2453
DEBUG - 2013-08-05 10:17:23 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:23 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:23 --> Router Class Initialized
ERROR - 2013-08-05 10:17:23 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:17:30 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:30 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:30 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:31 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:31 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:31 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:31 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:31 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:31 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:31 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:31 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:31 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:31 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:31 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:31 --> Total execution time: 0.2324
DEBUG - 2013-08-05 10:17:31 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:31 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:31 --> Router Class Initialized
ERROR - 2013-08-05 10:17:31 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:17:43 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:43 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:43 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:43 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:43 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:43 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:43 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:43 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:43 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:43 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:43 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:43 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:43 --> Total execution time: 0.2493
DEBUG - 2013-08-05 10:17:43 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:43 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:43 --> Router Class Initialized
ERROR - 2013-08-05 10:17:43 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:17:51 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:51 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Router Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Output Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Security Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Input Class Initialized
DEBUG - 2013-08-05 10:17:51 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:51 --> XSS Filtering completed
DEBUG - 2013-08-05 10:17:51 --> CRSF cookie Set
DEBUG - 2013-08-05 10:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:17:51 --> Language Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Loader Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:17:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:17:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Session Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:17:51 --> Session routines successfully run
DEBUG - 2013-08-05 10:17:51 --> Controller Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:17:51 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:17:51 --> Final output sent to browser
DEBUG - 2013-08-05 10:17:51 --> Total execution time: 0.2325
DEBUG - 2013-08-05 10:17:51 --> Config Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:17:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:17:51 --> URI Class Initialized
DEBUG - 2013-08-05 10:17:51 --> Router Class Initialized
ERROR - 2013-08-05 10:17:51 --> 404 Page Not Found --> dashboard.css
DEBUG - 2013-08-05 10:18:20 --> Config Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:18:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:18:20 --> URI Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Router Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Output Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Security Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Input Class Initialized
DEBUG - 2013-08-05 10:18:20 --> XSS Filtering completed
DEBUG - 2013-08-05 10:18:20 --> XSS Filtering completed
DEBUG - 2013-08-05 10:18:20 --> CRSF cookie Set
DEBUG - 2013-08-05 10:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:18:20 --> Language Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Loader Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:18:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:18:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Session Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:18:20 --> Session routines successfully run
DEBUG - 2013-08-05 10:18:20 --> Controller Class Initialized
DEBUG - 2013-08-05 10:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:18:20 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:18:20 --> Final output sent to browser
DEBUG - 2013-08-05 10:18:20 --> Total execution time: 0.2592
DEBUG - 2013-08-05 10:18:56 --> Config Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:18:56 --> URI Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Router Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Output Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Security Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Input Class Initialized
DEBUG - 2013-08-05 10:18:56 --> XSS Filtering completed
DEBUG - 2013-08-05 10:18:56 --> XSS Filtering completed
DEBUG - 2013-08-05 10:18:56 --> CRSF cookie Set
DEBUG - 2013-08-05 10:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:18:56 --> Language Class Initialized
DEBUG - 2013-08-05 10:18:56 --> Loader Class Initialized
DEBUG - 2013-08-05 10:18:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:18:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:18:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:18:57 --> Session Class Initialized
DEBUG - 2013-08-05 10:18:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:18:57 --> Session routines successfully run
DEBUG - 2013-08-05 10:18:57 --> Controller Class Initialized
DEBUG - 2013-08-05 10:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:18:57 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:18:57 --> Final output sent to browser
DEBUG - 2013-08-05 10:18:57 --> Total execution time: 0.2513
DEBUG - 2013-08-05 10:21:19 --> Config Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:21:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:21:19 --> URI Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Router Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Output Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Security Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Input Class Initialized
DEBUG - 2013-08-05 10:21:19 --> XSS Filtering completed
DEBUG - 2013-08-05 10:21:19 --> XSS Filtering completed
DEBUG - 2013-08-05 10:21:19 --> CRSF cookie Set
DEBUG - 2013-08-05 10:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:21:19 --> Language Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Loader Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:21:19 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:21:19 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Session Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:21:19 --> Session routines successfully run
DEBUG - 2013-08-05 10:21:19 --> Controller Class Initialized
DEBUG - 2013-08-05 10:21:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:21:19 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:21:19 --> Final output sent to browser
DEBUG - 2013-08-05 10:21:19 --> Total execution time: 0.2432
DEBUG - 2013-08-05 10:22:24 --> Config Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:22:24 --> URI Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Router Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Output Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Security Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Input Class Initialized
DEBUG - 2013-08-05 10:22:24 --> XSS Filtering completed
DEBUG - 2013-08-05 10:22:24 --> XSS Filtering completed
DEBUG - 2013-08-05 10:22:24 --> CRSF cookie Set
DEBUG - 2013-08-05 10:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:22:24 --> Language Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Loader Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:22:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:22:24 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Session Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:22:24 --> Session routines successfully run
DEBUG - 2013-08-05 10:22:24 --> Controller Class Initialized
DEBUG - 2013-08-05 10:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:22:25 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:22:25 --> Final output sent to browser
DEBUG - 2013-08-05 10:22:25 --> Total execution time: 0.2392
DEBUG - 2013-08-05 10:23:29 --> Config Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:23:29 --> URI Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Router Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Output Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Security Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Input Class Initialized
DEBUG - 2013-08-05 10:23:29 --> XSS Filtering completed
DEBUG - 2013-08-05 10:23:29 --> XSS Filtering completed
DEBUG - 2013-08-05 10:23:29 --> CRSF cookie Set
DEBUG - 2013-08-05 10:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:23:29 --> Language Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Loader Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:23:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:23:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Session Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:23:29 --> Session routines successfully run
DEBUG - 2013-08-05 10:23:29 --> Controller Class Initialized
DEBUG - 2013-08-05 10:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:23:29 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:23:29 --> Final output sent to browser
DEBUG - 2013-08-05 10:23:29 --> Total execution time: 0.2559
DEBUG - 2013-08-05 10:25:48 --> Config Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:25:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:25:48 --> URI Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Router Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Output Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Security Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Input Class Initialized
DEBUG - 2013-08-05 10:25:48 --> XSS Filtering completed
DEBUG - 2013-08-05 10:25:48 --> XSS Filtering completed
DEBUG - 2013-08-05 10:25:48 --> CRSF cookie Set
DEBUG - 2013-08-05 10:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:25:48 --> Language Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Loader Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:25:48 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:25:48 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Session Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:25:48 --> Session routines successfully run
DEBUG - 2013-08-05 10:25:48 --> Controller Class Initialized
DEBUG - 2013-08-05 10:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:25:48 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:25:48 --> Final output sent to browser
DEBUG - 2013-08-05 10:25:48 --> Total execution time: 0.2630
DEBUG - 2013-08-05 10:26:24 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:24 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Output Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Security Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Input Class Initialized
DEBUG - 2013-08-05 10:26:24 --> XSS Filtering completed
DEBUG - 2013-08-05 10:26:24 --> XSS Filtering completed
DEBUG - 2013-08-05 10:26:24 --> CRSF cookie Set
DEBUG - 2013-08-05 10:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:26:24 --> Language Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Loader Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:26:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:26:24 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Session Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:26:24 --> Session routines successfully run
DEBUG - 2013-08-05 10:26:24 --> Controller Class Initialized
DEBUG - 2013-08-05 10:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:26:24 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:26:24 --> Final output sent to browser
DEBUG - 2013-08-05 10:26:24 --> Total execution time: 0.2624
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d33.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d55.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d22.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> dllb.png
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 10:26:25 --> Router Class Initialized
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> dllb.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d22.png
ERROR - 2013-08-05 10:26:25 --> 404 Page Not Found --> d33.png
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Config Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:26:26 --> URI Class Initialized
DEBUG - 2013-08-05 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:26:26 --> Router Class Initialized
DEBUG - 2013-08-05 10:26:26 --> URI Class Initialized
ERROR - 2013-08-05 10:26:26 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:26:26 --> Router Class Initialized
ERROR - 2013-08-05 10:26:26 --> 404 Page Not Found --> d55.png
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Output Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Security Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Input Class Initialized
DEBUG - 2013-08-05 10:31:32 --> XSS Filtering completed
DEBUG - 2013-08-05 10:31:32 --> XSS Filtering completed
DEBUG - 2013-08-05 10:31:32 --> CRSF cookie Set
DEBUG - 2013-08-05 10:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:31:32 --> Language Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Loader Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:31:32 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:31:32 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Session Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:31:32 --> Session routines successfully run
DEBUG - 2013-08-05 10:31:32 --> Controller Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:31:32 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:31:32 --> Final output sent to browser
DEBUG - 2013-08-05 10:31:32 --> Total execution time: 0.2670
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> d33.png
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 10:31:32 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Hooks Class Initialized
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> d22.png
DEBUG - 2013-08-05 10:31:32 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:32 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:32 --> Router Class Initialized
ERROR - 2013-08-05 10:31:32 --> 404 Page Not Found --> d55.png
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> d55.png
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> d33.png
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> d22.png
DEBUG - 2013-08-05 10:31:33 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:33 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:33 --> Router Class Initialized
ERROR - 2013-08-05 10:31:33 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:31:45 --> Config Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:31:45 --> URI Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Router Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Output Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Security Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Input Class Initialized
DEBUG - 2013-08-05 10:31:45 --> XSS Filtering completed
DEBUG - 2013-08-05 10:31:45 --> XSS Filtering completed
DEBUG - 2013-08-05 10:31:45 --> CRSF cookie Set
DEBUG - 2013-08-05 10:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:31:45 --> Language Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Loader Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:31:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:31:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Session Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:31:45 --> Session routines successfully run
DEBUG - 2013-08-05 10:31:45 --> Controller Class Initialized
DEBUG - 2013-08-05 10:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:31:45 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:31:45 --> Final output sent to browser
DEBUG - 2013-08-05 10:31:45 --> Total execution time: 0.2580
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Output Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Security Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Input Class Initialized
DEBUG - 2013-08-05 10:32:00 --> XSS Filtering completed
DEBUG - 2013-08-05 10:32:00 --> XSS Filtering completed
DEBUG - 2013-08-05 10:32:00 --> CRSF cookie Set
DEBUG - 2013-08-05 10:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:32:00 --> Language Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Loader Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:32:00 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:32:00 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Session Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:32:00 --> Session routines successfully run
DEBUG - 2013-08-05 10:32:00 --> Controller Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:32:00 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:32:00 --> Final output sent to browser
DEBUG - 2013-08-05 10:32:00 --> Total execution time: 0.2662
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
ERROR - 2013-08-05 10:32:00 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 10:32:00 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 10:32:00 --> Router Class Initialized
ERROR - 2013-08-05 10:32:00 --> 404 Page Not Found --> d55.png
ERROR - 2013-08-05 10:32:00 --> 404 Page Not Found --> d33.png
ERROR - 2013-08-05 10:32:00 --> 404 Page Not Found --> d22.png
DEBUG - 2013-08-05 10:32:00 --> Config Class Initialized
ERROR - 2013-08-05 10:32:00 --> 404 Page Not Found --> d44.png
DEBUG - 2013-08-05 10:32:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:00 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:01 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:01 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:01 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> UTF-8 Support Enabled
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:01 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:01 --> Router Class Initialized
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> d55.png
DEBUG - 2013-08-05 10:32:01 --> Config Class Initialized
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> d33.png
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> d22.png
DEBUG - 2013-08-05 10:32:01 --> Hooks Class Initialized
ERROR - 2013-08-05 10:32:01 --> 404 Page Not Found --> d44.png
DEBUG - 2013-08-05 10:32:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:02 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:02 --> Router Class Initialized
ERROR - 2013-08-05 10:32:02 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:36 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Output Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Security Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Input Class Initialized
DEBUG - 2013-08-05 10:32:36 --> XSS Filtering completed
DEBUG - 2013-08-05 10:32:36 --> XSS Filtering completed
DEBUG - 2013-08-05 10:32:36 --> CRSF cookie Set
DEBUG - 2013-08-05 10:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:32:36 --> Language Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Loader Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:32:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:32:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Session Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:32:36 --> Session routines successfully run
DEBUG - 2013-08-05 10:32:36 --> Controller Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:32:36 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:32:36 --> Final output sent to browser
DEBUG - 2013-08-05 10:32:36 --> Total execution time: 0.2873
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> d44.png
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Config Class Initialized
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> d33.png
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> d22.png
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Hooks Class Initialized
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> d55.png
DEBUG - 2013-08-05 10:32:37 --> Utf8 Class Initialized
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:37 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:37 --> Router Class Initialized
ERROR - 2013-08-05 10:32:37 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> d22.png
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> d55.png
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> d33.png
DEBUG - 2013-08-05 10:32:38 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:38 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:38 --> Router Class Initialized
ERROR - 2013-08-05 10:32:38 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:32:46 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:46 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Output Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Security Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Input Class Initialized
DEBUG - 2013-08-05 10:32:46 --> XSS Filtering completed
DEBUG - 2013-08-05 10:32:46 --> XSS Filtering completed
DEBUG - 2013-08-05 10:32:46 --> CRSF cookie Set
DEBUG - 2013-08-05 10:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:32:46 --> Language Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Loader Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:32:46 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:32:46 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Session Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:32:46 --> Session routines successfully run
DEBUG - 2013-08-05 10:32:46 --> Controller Class Initialized
DEBUG - 2013-08-05 10:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:32:46 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:32:46 --> Final output sent to browser
DEBUG - 2013-08-05 10:32:46 --> Total execution time: 0.3074
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> d55.png
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> d22.png
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> d33.png
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 10:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:47 --> UTF-8 Support Enabled
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 10:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:47 --> Router Class Initialized
ERROR - 2013-08-05 10:32:47 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> d22.png
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Config Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Hooks Class Initialized
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> d55.png
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> d33.png
DEBUG - 2013-08-05 10:32:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:32:55 --> UTF-8 Support Enabled
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> d44.png
DEBUG - 2013-08-05 10:32:55 --> URI Class Initialized
DEBUG - 2013-08-05 10:32:55 --> Router Class Initialized
ERROR - 2013-08-05 10:32:55 --> 404 Page Not Found --> d66.png
DEBUG - 2013-08-05 10:33:52 --> Config Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 10:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 10:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 10:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 10:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 10:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 10:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 10:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 10:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 10:33:53 --> Session routines successfully run
DEBUG - 2013-08-05 10:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 10:33:53 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 10:33:53 --> Final output sent to browser
DEBUG - 2013-08-05 10:33:53 --> Total execution time: 0.2854
DEBUG - 2013-08-05 10:33:53 --> Config Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Config Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:33:53 --> URI Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Router Class Initialized
DEBUG - 2013-08-05 10:33:53 --> URI Class Initialized
DEBUG - 2013-08-05 10:33:53 --> Router Class Initialized
ERROR - 2013-08-05 10:33:53 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 10:33:53 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 10:33:54 --> Config Class Initialized
DEBUG - 2013-08-05 10:33:54 --> Config Class Initialized
DEBUG - 2013-08-05 10:33:54 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:33:54 --> Hooks Class Initialized
DEBUG - 2013-08-05 10:33:54 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:33:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:33:54 --> Utf8 Class Initialized
DEBUG - 2013-08-05 10:33:54 --> URI Class Initialized
DEBUG - 2013-08-05 10:33:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 10:33:54 --> Router Class Initialized
DEBUG - 2013-08-05 10:33:54 --> URI Class Initialized
ERROR - 2013-08-05 10:33:54 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 10:33:54 --> Router Class Initialized
ERROR - 2013-08-05 10:33:54 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:06:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:17 --> No URI present. Default controller set.
DEBUG - 2013-08-05 12:06:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:17 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:17 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:17 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:17 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:17 --> A session cookie was not found.
DEBUG - 2013-08-05 12:06:17 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:17 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:18 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:18 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:18 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:18 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:18 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:18 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:18 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:18 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:18 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:18 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:18 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 12:06:18 --> Final output sent to browser
DEBUG - 2013-08-05 12:06:18 --> Total execution time: 0.2650
DEBUG - 2013-08-05 12:06:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Config Class Initialized
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:26 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Config Class Initialized
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:26 --> Router Class Initialized
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:26 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:26 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:26 --> Session Class Initialized
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:26 --> Helper loaded: form_helper
ERROR - 2013-08-05 12:06:26 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:27 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:27 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:27 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:27 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:27 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:27 --> Session Class Initialized
ERROR - 2013-08-05 12:06:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:27 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:06:27 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:27 --> Session routines successfully run
ERROR - 2013-08-05 12:06:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:27 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:27 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:34 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:34 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:35 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:35 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:35 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:35 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:35 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:35 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:35 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:35 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:35 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:35 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:35 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:35 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:35 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:35 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:35 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:35 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:35 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:35 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:35 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:35 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:35 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:35 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:36 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:36 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:36 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:36 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:36 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:36 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:36 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:36 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:36 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:36 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:36 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:36 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:36 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:37 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:37 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:37 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:37 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:37 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:37 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:37 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:37 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:37 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:37 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:37 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:37 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:37 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:37 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:37 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:37 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:37 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:37 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:06:38 --> Config Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:06:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:06:38 --> URI Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Router Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Output Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Security Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Input Class Initialized
DEBUG - 2013-08-05 12:06:38 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:38 --> XSS Filtering completed
DEBUG - 2013-08-05 12:06:38 --> CRSF cookie Set
DEBUG - 2013-08-05 12:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:06:38 --> Language Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Loader Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:06:38 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:06:38 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Session Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:06:38 --> Session routines successfully run
DEBUG - 2013-08-05 12:06:38 --> Controller Class Initialized
DEBUG - 2013-08-05 12:06:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:06:38 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:02 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:02 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:02 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 12:07:02 --> Final output sent to browser
DEBUG - 2013-08-05 12:07:02 --> Total execution time: 0.3035
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:02 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:02 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:02 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:02 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:02 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:02 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Loader Class Initialized
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: url_helper
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:03 --> URI Class Initialized
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
ERROR - 2013-08-05 12:07:03 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:04 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:04 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:04 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:05 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:05 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:05 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:05 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:05 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:05 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:05 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:05 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:05 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:06 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:06 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:06 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:06 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:06 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:06 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:06 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:06 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:06 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:06 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:06 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:06 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:06 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:06 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:06 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:06 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:06 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:06 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:06 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:06 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:06 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:06 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:06 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:06 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:06 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:06 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:06 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:06 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:06 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:06 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:06 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:07 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:07 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:07 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:07 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:07 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:07 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:07 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:07 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:07 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:07 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:07 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:07 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:07 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:07 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:07 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:07 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:07:07 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:07:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:07:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:07:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:07:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:07:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:07:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:07:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:07:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:07:14 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:07:14 --> Final output sent to browser
DEBUG - 2013-08-05 12:07:14 --> Total execution time: 0.3240
DEBUG - 2013-08-05 12:07:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:14 --> Router Class Initialized
ERROR - 2013-08-05 12:07:14 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:07:14 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:07:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:21 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:21 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:21 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:21 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:21 --> Router Class Initialized
DEBUG - 2013-08-05 12:07:21 --> Router Class Initialized
ERROR - 2013-08-05 12:07:21 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:07:21 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:07:22 --> Config Class Initialized
DEBUG - 2013-08-05 12:07:22 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:07:22 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:07:22 --> URI Class Initialized
DEBUG - 2013-08-05 12:07:22 --> Router Class Initialized
ERROR - 2013-08-05 12:07:22 --> 404 Page Not Found --> loading2.html
DEBUG - 2013-08-05 12:08:22 --> Config Class Initialized
DEBUG - 2013-08-05 12:08:22 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:08:22 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:08:22 --> URI Class Initialized
DEBUG - 2013-08-05 12:08:22 --> Router Class Initialized
ERROR - 2013-08-05 12:08:22 --> 404 Page Not Found --> loading2.html
DEBUG - 2013-08-05 12:08:23 --> Config Class Initialized
DEBUG - 2013-08-05 12:08:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:08:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:08:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:08:24 --> URI Class Initialized
DEBUG - 2013-08-05 12:08:24 --> Router Class Initialized
ERROR - 2013-08-05 12:08:24 --> 404 Page Not Found --> loading2.html
DEBUG - 2013-08-05 12:18:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:18:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:18:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:18:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:18:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:18:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:18:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:18:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:18:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:18:10 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:18:10 --> Final output sent to browser
DEBUG - 2013-08-05 12:18:10 --> Total execution time: 0.3240
DEBUG - 2013-08-05 12:18:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:18:10 --> Router Class Initialized
ERROR - 2013-08-05 12:18:10 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:18:10 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:18:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:18:13 --> Router Class Initialized
ERROR - 2013-08-05 12:18:13 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:18:13 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:18:35 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:35 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:35 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:35 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:35 --> Router Class Initialized
DEBUG - 2013-08-05 12:18:35 --> Output Class Initialized
DEBUG - 2013-08-05 12:18:35 --> Security Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:18:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:18:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:18:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:18:36 --> Language Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Loader Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:18:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:18:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Session Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:18:36 --> Session routines successfully run
DEBUG - 2013-08-05 12:18:36 --> Controller Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:18:36 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:18:36 --> Final output sent to browser
DEBUG - 2013-08-05 12:18:36 --> Total execution time: 0.3417
DEBUG - 2013-08-05 12:18:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:18:36 --> Router Class Initialized
ERROR - 2013-08-05 12:18:36 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:18:36 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:18:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:18:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:18:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:18:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:18:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:18:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:18:37 --> URI Class Initialized
ERROR - 2013-08-05 12:18:37 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:18:37 --> Router Class Initialized
ERROR - 2013-08-05 12:18:37 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:19:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:19:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:19:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:19:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:19:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:19:10 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:19:10 --> Final output sent to browser
DEBUG - 2013-08-05 12:19:10 --> Total execution time: 0.3519
DEBUG - 2013-08-05 12:19:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:11 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:11 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:11 --> URI Class Initialized
ERROR - 2013-08-05 12:19:11 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:19:11 --> Router Class Initialized
ERROR - 2013-08-05 12:19:11 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:19:11 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:11 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:11 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:11 --> Router Class Initialized
ERROR - 2013-08-05 12:19:11 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:19:11 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:19:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:12 --> Router Class Initialized
ERROR - 2013-08-05 12:19:12 --> 404 Page Not Found --> loading2.html
DEBUG - 2013-08-05 12:19:15 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:15 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:15 --> Router Class Initialized
ERROR - 2013-08-05 12:19:15 --> 404 Page Not Found --> loading2.html
DEBUG - 2013-08-05 12:19:16 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:16 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:16 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:17 --> Language Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Loader Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:19:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Session Class Initialized
DEBUG - 2013-08-05 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:19:17 --> Session routines successfully run
DEBUG - 2013-08-05 12:19:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Controller Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:19:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:17 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:19:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Final output sent to browser
DEBUG - 2013-08-05 12:19:17 --> Total execution time: 0.4031
DEBUG - 2013-08-05 12:19:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:17 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Language Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Loader Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:19:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:19:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Session Class Initialized
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:19:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:17 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:17 --> Session routines successfully run
DEBUG - 2013-08-05 12:19:17 --> Controller Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Language Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:19:17 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:19:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Loader Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Final output sent to browser
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:19:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Total execution time: 0.5791
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:19:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Session Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> Session routines successfully run
DEBUG - 2013-08-05 12:19:17 --> Controller Class Initialized
DEBUG - 2013-08-05 12:19:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:17 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:17 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:19:17 --> Language Class Initialized
DEBUG - 2013-08-05 12:19:17 --> Final output sent to browser
DEBUG - 2013-08-05 12:19:18 --> Total execution time: 0.5570
DEBUG - 2013-08-05 12:19:18 --> Loader Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:19:18 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:19:18 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Session Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:19:18 --> Session routines successfully run
DEBUG - 2013-08-05 12:19:18 --> Controller Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:19:18 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:19:18 --> Final output sent to browser
DEBUG - 2013-08-05 12:19:18 --> Total execution time: 0.5194
DEBUG - 2013-08-05 12:19:18 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:18 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:18 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:18 --> Router Class Initialized
ERROR - 2013-08-05 12:19:18 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:19:18 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:19:19 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:19 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:19 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:19 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:20 --> Router Class Initialized
ERROR - 2013-08-05 12:19:20 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:19:20 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:19:35 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:35 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:36 --> Language Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Loader Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:19:36 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:19:36 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Session Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:19:36 --> Session routines successfully run
DEBUG - 2013-08-05 12:19:36 --> Controller Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:19:36 --> File loaded: application/views/teacher/dashboard.php
DEBUG - 2013-08-05 12:19:36 --> Final output sent to browser
DEBUG - 2013-08-05 12:19:36 --> Total execution time: 0.3826
DEBUG - 2013-08-05 12:19:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:36 --> Router Class Initialized
ERROR - 2013-08-05 12:19:36 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:19:36 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:19:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:37 --> Router Class Initialized
ERROR - 2013-08-05 12:19:37 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:19:37 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:19:59 --> Config Class Initialized
DEBUG - 2013-08-05 12:19:59 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:19:59 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:19:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:19:59 --> URI Class Initialized
DEBUG - 2013-08-05 12:19:59 --> Router Class Initialized
DEBUG - 2013-08-05 12:19:59 --> Output Class Initialized
DEBUG - 2013-08-05 12:19:59 --> Security Class Initialized
DEBUG - 2013-08-05 12:19:59 --> Input Class Initialized
DEBUG - 2013-08-05 12:19:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:19:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:19:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Config Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:20:41 --> URI Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Router Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Output Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Security Class Initialized
DEBUG - 2013-08-05 12:20:41 --> Input Class Initialized
DEBUG - 2013-08-05 12:20:41 --> XSS Filtering completed
DEBUG - 2013-08-05 12:20:41 --> XSS Filtering completed
DEBUG - 2013-08-05 12:20:41 --> CRSF cookie Set
DEBUG - 2013-08-05 12:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:20:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Config Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:20:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:20:55 --> URI Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Router Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Output Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Security Class Initialized
DEBUG - 2013-08-05 12:20:55 --> Input Class Initialized
DEBUG - 2013-08-05 12:20:55 --> XSS Filtering completed
DEBUG - 2013-08-05 12:20:55 --> XSS Filtering completed
DEBUG - 2013-08-05 12:20:55 --> CRSF cookie Set
DEBUG - 2013-08-05 12:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:20:55 --> Language Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:07 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Output Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Security Class Initialized
DEBUG - 2013-08-05 12:21:07 --> Input Class Initialized
DEBUG - 2013-08-05 12:21:07 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:07 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:07 --> CRSF cookie Set
DEBUG - 2013-08-05 12:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:21:07 --> Language Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:23 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Output Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Security Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Input Class Initialized
DEBUG - 2013-08-05 12:21:23 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:23 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:23 --> CRSF cookie Set
DEBUG - 2013-08-05 12:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:21:23 --> Language Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Loader Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:21:23 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:21:23 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Session Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:21:23 --> Session routines successfully run
DEBUG - 2013-08-05 12:21:23 --> Controller Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:21:23 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:21:23 --> Final output sent to browser
DEBUG - 2013-08-05 12:21:23 --> Total execution time: 0.3523
DEBUG - 2013-08-05 12:21:23 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:23 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:23 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:23 --> Router Class Initialized
ERROR - 2013-08-05 12:21:23 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:21:23 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:21:24 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:24 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:24 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:24 --> Router Class Initialized
ERROR - 2013-08-05 12:21:24 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:21:24 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:21:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:21:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:21:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:21:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:21:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:21:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:21:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:21:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:21:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:52 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:21:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Final output sent to browser
DEBUG - 2013-08-05 12:21:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Total execution time: 0.4133
DEBUG - 2013-08-05 12:21:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:21:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:21:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:21:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:21:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:21:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:21:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:21:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:21:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:21:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:21:52 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:21:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Final output sent to browser
DEBUG - 2013-08-05 12:21:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Total execution time: 0.6274
DEBUG - 2013-08-05 12:21:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:21:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:21:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:21:52 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:21:52 --> Final output sent to browser
DEBUG - 2013-08-05 12:21:52 --> Total execution time: 0.5515
DEBUG - 2013-08-05 12:21:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Router Class Initialized
ERROR - 2013-08-05 12:21:53 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:21:53 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:21:53 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Config Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:21:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:21:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:21:53 --> Router Class Initialized
ERROR - 2013-08-05 12:21:53 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:21:53 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:22:40 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:40 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:40 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:40 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:40 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:40 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:40 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:40 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:40 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:40 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:40 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:22:40 --> Final output sent to browser
DEBUG - 2013-08-05 12:22:40 --> Total execution time: 0.3596
DEBUG - 2013-08-05 12:22:40 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:40 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:40 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Router Class Initialized
ERROR - 2013-08-05 12:22:40 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:22:40 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:22:40 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:40 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:40 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:40 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:41 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:41 --> Router Class Initialized
ERROR - 2013-08-05 12:22:41 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:22:41 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:22:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:42 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:42 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:42 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:42 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:42 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:22:42 --> Final output sent to browser
DEBUG - 2013-08-05 12:22:42 --> Total execution time: 0.3808
DEBUG - 2013-08-05 12:22:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:42 --> Router Class Initialized
ERROR - 2013-08-05 12:22:42 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:22:42 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:22:43 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:43 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:43 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:43 --> Router Class Initialized
ERROR - 2013-08-05 12:22:43 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:22:43 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:22:56 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:56 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:56 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:56 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:56 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:56 --> No URI present. Default controller set.
DEBUG - 2013-08-05 12:22:56 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:56 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:57 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:57 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:57 --> A session cookie was not found.
DEBUG - 2013-08-05 12:22:57 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:57 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:57 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:57 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:57 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:57 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:57 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:57 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:57 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 12:22:57 --> Final output sent to browser
DEBUG - 2013-08-05 12:22:57 --> Total execution time: 0.3659
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:57 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:58 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:58 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:58 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:58 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:58 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:58 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:58 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:58 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:58 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:58 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:58 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:58 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:58 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:58 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:22:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:58 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:58 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:22:58 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 12:22:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:58 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Config Class Initialized
ERROR - 2013-08-05 12:22:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Config Class Initialized
ERROR - 2013-08-05 12:22:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:58 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:58 --> Hooks Class Initialized
ERROR - 2013-08-05 12:22:58 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:58 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:58 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:58 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:58 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:58 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:58 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Config Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:22:58 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:58 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> URI Class Initialized
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> Router Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:59 --> Output Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:59 --> Security Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Input Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:22:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:22:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:22:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:59 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:59 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: form_helper
ERROR - 2013-08-05 12:22:59 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:22:59 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Database Driver Class Initialized
ERROR - 2013-08-05 12:22:59 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:22:59 --> Controller Class Initialized
ERROR - 2013-08-05 12:22:59 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:22:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:22:59 --> Controller Class Initialized
DEBUG - 2013-08-05 12:22:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:22:59 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 12:22:59 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 12:23:01 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:01 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Router Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Output Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Security Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Input Class Initialized
DEBUG - 2013-08-05 12:23:01 --> XSS Filtering completed
DEBUG - 2013-08-05 12:23:01 --> XSS Filtering completed
DEBUG - 2013-08-05 12:23:01 --> CRSF cookie Set
DEBUG - 2013-08-05 12:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:23:01 --> Language Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Loader Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:23:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:23:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:23:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:23:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:23:01 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:23:01 --> Final output sent to browser
DEBUG - 2013-08-05 12:23:01 --> Total execution time: 0.3865
DEBUG - 2013-08-05 12:23:01 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:01 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:01 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Router Class Initialized
DEBUG - 2013-08-05 12:23:01 --> Router Class Initialized
ERROR - 2013-08-05 12:23:01 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:23:01 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:23:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:04 --> Router Class Initialized
ERROR - 2013-08-05 12:23:04 --> 404 Page Not Found --> loading2.html
DEBUG - 2013-08-05 12:23:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:23:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:23:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:23:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:23:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:23:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:23:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:23:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:23:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:23:52 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:23:52 --> Final output sent to browser
DEBUG - 2013-08-05 12:23:52 --> Total execution time: 0.3932
DEBUG - 2013-08-05 12:23:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:23:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:23:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:23:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:23:53 --> Router Class Initialized
ERROR - 2013-08-05 12:23:53 --> 404 Page Not Found --> d33.png
DEBUG - 2013-08-05 12:23:53 --> Router Class Initialized
ERROR - 2013-08-05 12:23:53 --> 404 Page Not Found --> d44.png
ERROR - 2013-08-05 12:23:53 --> 404 Page Not Found --> d22.png
ERROR - 2013-08-05 12:23:53 --> 404 Page Not Found --> d66.png
ERROR - 2013-08-05 12:23:53 --> 404 Page Not Found --> d55.png
DEBUG - 2013-08-05 12:25:08 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:08 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Router Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Output Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Security Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Input Class Initialized
DEBUG - 2013-08-05 12:25:08 --> XSS Filtering completed
DEBUG - 2013-08-05 12:25:08 --> XSS Filtering completed
DEBUG - 2013-08-05 12:25:08 --> CRSF cookie Set
DEBUG - 2013-08-05 12:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:25:08 --> Language Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Loader Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:25:08 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:25:08 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Session Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:25:08 --> Session routines successfully run
DEBUG - 2013-08-05 12:25:08 --> Controller Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:25:08 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:25:08 --> Final output sent to browser
DEBUG - 2013-08-05 12:25:08 --> Total execution time: 0.4062
DEBUG - 2013-08-05 12:25:08 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:08 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:08 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Router Class Initialized
DEBUG - 2013-08-05 12:25:08 --> Router Class Initialized
ERROR - 2013-08-05 12:25:08 --> 404 Page Not Found --> pisaralogo2.png
ERROR - 2013-08-05 12:25:08 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:25:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:25:12 --> Router Class Initialized
ERROR - 2013-08-05 12:25:12 --> 404 Page Not Found --> logoutsign.png
ERROR - 2013-08-05 12:25:12 --> 404 Page Not Found --> pisaralogo2.png
DEBUG - 2013-08-05 12:25:49 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:49 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Router Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Output Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Security Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Input Class Initialized
DEBUG - 2013-08-05 12:25:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:25:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:25:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:25:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:25:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:25:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:25:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:25:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:25:49 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:25:49 --> Final output sent to browser
DEBUG - 2013-08-05 12:25:49 --> Total execution time: 0.4014
DEBUG - 2013-08-05 12:25:49 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:50 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:50 --> Router Class Initialized
ERROR - 2013-08-05 12:25:50 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:25:50 --> Config Class Initialized
DEBUG - 2013-08-05 12:25:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:25:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:25:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:25:50 --> URI Class Initialized
DEBUG - 2013-08-05 12:25:51 --> Router Class Initialized
ERROR - 2013-08-05 12:25:51 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:26:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:26:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:26:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:26:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:26:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:26:00 --> Language Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Loader Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:26:00 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:26:00 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Session Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:26:00 --> Session routines successfully run
DEBUG - 2013-08-05 12:26:00 --> Controller Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:26:00 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:26:00 --> Final output sent to browser
DEBUG - 2013-08-05 12:26:00 --> Total execution time: 0.3933
DEBUG - 2013-08-05 12:26:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:26:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:26:00 --> Router Class Initialized
ERROR - 2013-08-05 12:26:00 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:26:02 --> Config Class Initialized
DEBUG - 2013-08-05 12:26:02 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:26:02 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:26:02 --> URI Class Initialized
DEBUG - 2013-08-05 12:26:02 --> Router Class Initialized
ERROR - 2013-08-05 12:26:02 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:26:11 --> Config Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:26:11 --> URI Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Router Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Output Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Security Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Input Class Initialized
DEBUG - 2013-08-05 12:26:11 --> XSS Filtering completed
DEBUG - 2013-08-05 12:26:11 --> XSS Filtering completed
DEBUG - 2013-08-05 12:26:11 --> CRSF cookie Set
DEBUG - 2013-08-05 12:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:26:11 --> Language Class Initialized
DEBUG - 2013-08-05 12:26:11 --> Loader Class Initialized
DEBUG - 2013-08-05 12:26:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:26:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:26:12 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:26:12 --> Session Class Initialized
DEBUG - 2013-08-05 12:26:12 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:26:12 --> Session routines successfully run
DEBUG - 2013-08-05 12:26:12 --> Controller Class Initialized
DEBUG - 2013-08-05 12:26:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:26:12 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:26:12 --> Final output sent to browser
DEBUG - 2013-08-05 12:26:12 --> Total execution time: 0.3934
DEBUG - 2013-08-05 12:28:11 --> Config Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:28:11 --> URI Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Router Class Initialized
DEBUG - 2013-08-05 12:28:11 --> No URI present. Default controller set.
DEBUG - 2013-08-05 12:28:11 --> Output Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Security Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Input Class Initialized
DEBUG - 2013-08-05 12:28:11 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:11 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:11 --> CRSF cookie Set
DEBUG - 2013-08-05 12:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:28:11 --> Language Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Loader Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:28:11 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:28:11 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Session Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:28:11 --> Session routines successfully run
DEBUG - 2013-08-05 12:28:11 --> Controller Class Initialized
DEBUG - 2013-08-05 12:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:28:11 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:28:11 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 12:28:11 --> Final output sent to browser
DEBUG - 2013-08-05 12:28:11 --> Total execution time: 0.4112
DEBUG - 2013-08-05 12:28:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:28:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:28:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:28:37 --> No URI present. Default controller set.
DEBUG - 2013-08-05 12:28:37 --> Output Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Security Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Input Class Initialized
DEBUG - 2013-08-05 12:28:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:37 --> CRSF cookie Set
DEBUG - 2013-08-05 12:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:28:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:28:37 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:28:37 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:28:37 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:28:38 --> Session Class Initialized
DEBUG - 2013-08-05 12:28:38 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:28:38 --> Session routines successfully run
DEBUG - 2013-08-05 12:28:38 --> Controller Class Initialized
DEBUG - 2013-08-05 12:28:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:28:38 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:28:38 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 12:28:38 --> Final output sent to browser
DEBUG - 2013-08-05 12:28:38 --> Total execution time: 1.5121
DEBUG - 2013-08-05 12:28:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:28:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Output Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Security Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Input Class Initialized
DEBUG - 2013-08-05 12:28:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:42 --> CRSF cookie Set
DEBUG - 2013-08-05 12:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:28:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Loader Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:28:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:28:42 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Session Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:28:42 --> Session routines successfully run
DEBUG - 2013-08-05 12:28:42 --> Controller Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:28:42 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:28:42 --> Final output sent to browser
DEBUG - 2013-08-05 12:28:42 --> Total execution time: 0.3818
DEBUG - 2013-08-05 12:28:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:28:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:28:43 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:28:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:28:43 --> URI Class Initialized
DEBUG - 2013-08-05 12:28:43 --> Router Class Initialized
ERROR - 2013-08-05 12:28:43 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:28:50 --> Config Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:28:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:28:50 --> URI Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Router Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Output Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Security Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Input Class Initialized
DEBUG - 2013-08-05 12:28:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:28:50 --> CRSF cookie Set
DEBUG - 2013-08-05 12:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:28:50 --> Language Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Loader Class Initialized
DEBUG - 2013-08-05 12:28:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:28:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:28:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:28:51 --> Session Class Initialized
DEBUG - 2013-08-05 12:28:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:28:51 --> Session routines successfully run
DEBUG - 2013-08-05 12:28:51 --> Controller Class Initialized
DEBUG - 2013-08-05 12:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:28:51 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:28:51 --> Final output sent to browser
DEBUG - 2013-08-05 12:28:51 --> Total execution time: 1.4073
DEBUG - 2013-08-05 12:28:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:28:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:28:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:28:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:28:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:28:52 --> Router Class Initialized
ERROR - 2013-08-05 12:28:52 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:29:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:12 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:29:13 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:29:13 --> Final output sent to browser
DEBUG - 2013-08-05 12:29:13 --> Total execution time: 1.4455
DEBUG - 2013-08-05 12:29:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Router Class Initialized
ERROR - 2013-08-05 12:29:13 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:29:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:14 --> Router Class Initialized
ERROR - 2013-08-05 12:29:14 --> 404 Page Not Found --> logoutsign.png
DEBUG - 2013-08-05 12:29:15 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:15 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:15 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:15 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:15 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:15 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:15 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:15 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:15 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:16 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:16 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:16 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:16 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:29:16 --> 404 Page Not Found --> loader/v2
DEBUG - 2013-08-05 12:29:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:29:45 --> 404 Page Not Found --> loader/v2
DEBUG - 2013-08-05 12:29:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:48 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:48 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:48 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:48 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:48 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:48 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:29:48 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 12:29:48 --> Final output sent to browser
DEBUG - 2013-08-05 12:29:48 --> Total execution time: 0.4063
DEBUG - 2013-08-05 12:29:50 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:50 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:50 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:50 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:51 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:51 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:51 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:29:51 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:29:51 --> Final output sent to browser
DEBUG - 2013-08-05 12:29:51 --> Total execution time: 1.4056
DEBUG - 2013-08-05 12:29:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:29:52 --> Final output sent to browser
DEBUG - 2013-08-05 12:29:52 --> Total execution time: 0.3702
DEBUG - 2013-08-05 12:29:55 --> Config Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:29:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:29:55 --> URI Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Router Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Output Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Security Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Input Class Initialized
DEBUG - 2013-08-05 12:29:55 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:55 --> XSS Filtering completed
DEBUG - 2013-08-05 12:29:55 --> CRSF cookie Set
DEBUG - 2013-08-05 12:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:29:55 --> Language Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Loader Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:29:55 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:29:55 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Session Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:29:55 --> Session routines successfully run
DEBUG - 2013-08-05 12:29:55 --> Controller Class Initialized
DEBUG - 2013-08-05 12:29:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:29:55 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:30:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:30:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:30:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:30:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:30:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:30:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:30:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:30:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:30:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:30:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:30:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:30:04 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:31:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:31:10 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:31:15 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:15 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:15 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:15 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:15 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:15 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:15 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:15 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:16 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:16 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:16 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:16 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:16 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:16 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:16 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:31:24 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:24 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:24 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:24 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:24 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:24 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:24 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:25 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:25 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:31:25 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:31:25 --> Final output sent to browser
DEBUG - 2013-08-05 12:31:25 --> Total execution time: 1.4277
DEBUG - 2013-08-05 12:31:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:25 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:25 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:25 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:25 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:25 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:25 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:31:25 --> Final output sent to browser
DEBUG - 2013-08-05 12:31:25 --> Total execution time: 0.3750
DEBUG - 2013-08-05 12:31:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:31:29 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:31:34 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:34 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:34 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:34 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:34 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:34 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:34 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:34 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:34 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:34 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:34 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:34 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:35 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:35 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:35 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:35 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:35 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:35 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:35 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:35 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:35 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:31:35 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:31:41 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:41 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:41 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:41 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:41 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:41 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:41 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:41 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:41 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:41 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:31:41 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:31:41 --> Final output sent to browser
DEBUG - 2013-08-05 12:31:41 --> Total execution time: 0.3991
DEBUG - 2013-08-05 12:31:41 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:41 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:42 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:42 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:42 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:42 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:31:42 --> Final output sent to browser
DEBUG - 2013-08-05 12:31:42 --> Total execution time: 0.3799
DEBUG - 2013-08-05 12:31:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:31:45 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:31:50 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:50 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:50 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:50 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:50 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:50 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:31:50 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:31:53 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:53 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:53 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:53 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:53 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:53 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:53 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:31:53 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:31:53 --> Final output sent to browser
DEBUG - 2013-08-05 12:31:53 --> Total execution time: 0.4119
DEBUG - 2013-08-05 12:31:56 --> Config Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:31:56 --> URI Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Router Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Output Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Security Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Input Class Initialized
DEBUG - 2013-08-05 12:31:56 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:56 --> XSS Filtering completed
DEBUG - 2013-08-05 12:31:56 --> CRSF cookie Set
DEBUG - 2013-08-05 12:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:31:56 --> Language Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Loader Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:31:56 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:31:56 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Session Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:31:56 --> Session routines successfully run
DEBUG - 2013-08-05 12:31:56 --> Controller Class Initialized
DEBUG - 2013-08-05 12:31:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:31:57 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:32:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:32:15 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:32:15 --> Final output sent to browser
DEBUG - 2013-08-05 12:32:15 --> Total execution time: 0.4356
DEBUG - 2013-08-05 12:32:18 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:18 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:18 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:18 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:18 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:18 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:18 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:18 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:18 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:32:18 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:32:30 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:30 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:30 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:30 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:30 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:30 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:30 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:30 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:30 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:30 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:30 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:30 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:30 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:31 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:31 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:31 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:31 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:31 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:31 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:31 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:31 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:32:31 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:32:33 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:33 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:33 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:33 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:33 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:33 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:33 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:33 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:33 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:33 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:33 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:32:33 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:32:33 --> Final output sent to browser
DEBUG - 2013-08-05 12:32:33 --> Total execution time: 0.4379
DEBUG - 2013-08-05 12:32:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:36 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:36 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:37 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:37 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:37 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:37 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:37 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:37 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:37 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:32:37 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:32:47 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:47 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:47 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:47 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:47 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:47 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:47 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:47 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:47 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:47 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:32:47 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:32:49 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:49 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:32:50 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:32:50 --> Final output sent to browser
DEBUG - 2013-08-05 12:32:50 --> Total execution time: 0.4138
DEBUG - 2013-08-05 12:32:53 --> Config Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:32:53 --> URI Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Router Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Output Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Security Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Input Class Initialized
DEBUG - 2013-08-05 12:32:53 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:53 --> XSS Filtering completed
DEBUG - 2013-08-05 12:32:53 --> CRSF cookie Set
DEBUG - 2013-08-05 12:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:32:53 --> Language Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Loader Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:32:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:32:53 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Session Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:32:53 --> Session routines successfully run
DEBUG - 2013-08-05 12:32:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:32:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:32:53 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:33:19 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:19 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:19 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:19 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:19 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:19 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:19 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:19 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:19 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:19 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:31 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:31 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:31 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:31 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:31 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:31 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:31 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:32 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:32 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:32 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:32 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:32 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:32 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:32 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:32 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:33:32 --> 404 Page Not Found --> teacher/class
DEBUG - 2013-08-05 12:33:46 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:47 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:47 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:47 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:47 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:47 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:47 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:47 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:47 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:47 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:47 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:33:47 --> Final output sent to browser
DEBUG - 2013-08-05 12:33:47 --> Total execution time: 0.7363
DEBUG - 2013-08-05 12:33:50 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:50 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:50 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:50 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:51 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:51 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:51 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:33:51 --> Final output sent to browser
DEBUG - 2013-08-05 12:33:51 --> Total execution time: 0.4637
DEBUG - 2013-08-05 12:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:51 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:51 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:51 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:51 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:33:52 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 12:33:52 --> 404 Page Not Found --> teacher/d22.png
ERROR - 2013-08-05 12:33:52 --> 404 Page Not Found --> teacher/logoutsign.png
ERROR - 2013-08-05 12:33:52 --> 404 Page Not Found --> teacher/d11b.png
ERROR - 2013-08-05 12:33:52 --> 404 Page Not Found --> teacher/grades.css
DEBUG - 2013-08-05 12:33:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Config Class Initialized
ERROR - 2013-08-05 12:33:52 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Config Class Initialized
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:33:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:33:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:53 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:53 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:53 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Database Driver Class Initialized
ERROR - 2013-08-05 12:33:53 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:33:53 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Session Class Initialized
ERROR - 2013-08-05 12:33:53 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:53 --> Session Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:33:53 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:53 --> Session routines successfully run
DEBUG - 2013-08-05 12:33:53 --> Session routines successfully run
ERROR - 2013-08-05 12:33:53 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:33:53 --> Controller Class Initialized
DEBUG - 2013-08-05 12:33:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:33:53 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:33:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:33:53 --> 404 Page Not Found --> teacher/logoutsign.png
ERROR - 2013-08-05 12:33:53 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:35:43 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:43 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:43 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:43 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:43 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:43 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:43 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:43 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:43 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:43 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:44 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:44 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:35:44 --> Final output sent to browser
DEBUG - 2013-08-05 12:35:44 --> Total execution time: 0.4221
DEBUG - 2013-08-05 12:35:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:44 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:44 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:44 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:44 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:44 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:44 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:35:44 --> 404 Page Not Found --> teacher/grades.css
DEBUG - 2013-08-05 12:35:45 --> Session routines successfully run
ERROR - 2013-08-05 12:35:45 --> 404 Page Not Found --> teacher/logoutsign.png
ERROR - 2013-08-05 12:35:45 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:35:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:35:45 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:35:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Hooks Class Initialized
ERROR - 2013-08-05 12:35:45 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:35:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Utf8 Class Initialized
ERROR - 2013-08-05 12:35:45 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Config Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:35:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:45 --> URI Class Initialized
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Router Class Initialized
DEBUG - 2013-08-05 12:35:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Output Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Security Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Input Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> XSS Filtering completed
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:45 --> CRSF cookie Set
DEBUG - 2013-08-05 12:35:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Language Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:45 --> Loader Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:35:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Database Driver Class Initialized
ERROR - 2013-08-05 12:35:45 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:35:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:46 --> Helper loaded: string_helper
ERROR - 2013-08-05 12:35:46 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:35:46 --> Session routines successfully run
ERROR - 2013-08-05 12:35:46 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:35:46 --> Session routines successfully run
DEBUG - 2013-08-05 12:35:46 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:46 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:46 --> Controller Class Initialized
DEBUG - 2013-08-05 12:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:35:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:35:46 --> 404 Page Not Found --> teacher/d22.png
ERROR - 2013-08-05 12:35:46 --> 404 Page Not Found --> teacher/logoutsign.png
ERROR - 2013-08-05 12:35:46 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:12 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:12 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:12 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:12 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:36:12 --> Final output sent to browser
DEBUG - 2013-08-05 12:36:12 --> Total execution time: 0.4431
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:36:13 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:36:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:36:13 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 12:36:13 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 12:36:13 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:36:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Helper loaded: string_helper
ERROR - 2013-08-05 12:36:13 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:36:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:13 --> UTF-8 Support Enabled
ERROR - 2013-08-05 12:36:13 --> 404 Page Not Found --> teacher/logoutsign.png
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:36:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:36:14 --> Global POST and COOKIE data sanitized
ERROR - 2013-08-05 12:36:14 --> 404 Page Not Found --> teacher/d55.png
ERROR - 2013-08-05 12:36:14 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:36:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:36:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:36:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:36:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:15 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:15 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:36:15 --> Session routines successfully run
DEBUG - 2013-08-05 12:36:15 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:36:15 --> 404 Page Not Found --> teacher/logoutsign.png
DEBUG - 2013-08-05 12:36:15 --> Controller Class Initialized
DEBUG - 2013-08-05 12:36:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:36:15 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:36:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:36:15 --> 404 Page Not Found --> teacher/d11b.png
ERROR - 2013-08-05 12:36:15 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:28 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:28 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:28 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:28 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:28 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:37:28 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:37:28 --> Final output sent to browser
DEBUG - 2013-08-05 12:37:28 --> Total execution time: 0.4524
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:28 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:28 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:28 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:28 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:29 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:37:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:37:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:37:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:37:29 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: string_helper
ERROR - 2013-08-05 12:37:29 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:37:29 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:29 --> Config Class Initialized
ERROR - 2013-08-05 12:37:29 --> 404 Page Not Found --> teacher/d22.png
ERROR - 2013-08-05 12:37:29 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:37:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:37:29 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:37:29 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:37:29 --> Config Class Initialized
DEBUG - 2013-08-05 12:37:29 --> URI Class Initialized
ERROR - 2013-08-05 12:37:29 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:37:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:37:29 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:29 --> URI Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Router Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Output Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Security Class Initialized
DEBUG - 2013-08-05 12:37:29 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> Input Class Initialized
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:29 --> XSS Filtering completed
DEBUG - 2013-08-05 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:29 --> CRSF cookie Set
DEBUG - 2013-08-05 12:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:37:30 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Language Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Loader Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:30 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:37:30 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:30 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:37:30 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Session Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:30 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:37:30 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:30 --> Session routines successfully run
DEBUG - 2013-08-05 12:37:30 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Controller Class Initialized
DEBUG - 2013-08-05 12:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:37:30 --> 404 Page Not Found --> teacher/d66.png
ERROR - 2013-08-05 12:37:30 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:03 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:03 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:03 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:03 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:38:03 --> Final output sent to browser
DEBUG - 2013-08-05 12:38:03 --> Total execution time: 0.4789
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:04 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:04 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:04 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:04 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Controller Class Initialized
ERROR - 2013-08-05 12:38:04 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 12:38:04 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Config Class Initialized
ERROR - 2013-08-05 12:38:04 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:38:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:38:04 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:38:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:04 --> UTF-8 Support Enabled
ERROR - 2013-08-05 12:38:05 --> 404 Page Not Found --> teacher/d33.png
ERROR - 2013-08-05 12:38:05 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:38:05 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:05 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:05 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:05 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: form_helper
ERROR - 2013-08-05 12:38:05 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:05 --> Session routines successfully run
ERROR - 2013-08-05 12:38:05 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:38:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:38:05 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:38:41 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:41 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:41 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:41 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:42 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:42 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:42 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:42 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:42 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:38:42 --> Final output sent to browser
DEBUG - 2013-08-05 12:38:42 --> Total execution time: 0.4829
DEBUG - 2013-08-05 12:38:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Config Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:38:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:42 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:38:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:42 --> URI Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Router Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Output Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Security Class Initialized
DEBUG - 2013-08-05 12:38:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:42 --> Input Class Initialized
DEBUG - 2013-08-05 12:38:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:42 --> XSS Filtering completed
DEBUG - 2013-08-05 12:38:42 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:42 --> CRSF cookie Set
DEBUG - 2013-08-05 12:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:38:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Language Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Loader Class Initialized
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:38:43 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:43 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:38:43 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:43 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:43 --> Session Class Initialized
DEBUG - 2013-08-05 12:38:43 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:43 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:38:43 --> Controller Class Initialized
DEBUG - 2013-08-05 12:38:43 --> Session routines successfully run
DEBUG - 2013-08-05 12:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:38:43 --> Controller Class Initialized
ERROR - 2013-08-05 12:38:43 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:38:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:38:43 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:40:09 --> Config Class Initialized
DEBUG - 2013-08-05 12:40:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:40:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:40:09 --> URI Class Initialized
DEBUG - 2013-08-05 12:40:09 --> Router Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:40:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:40:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:40:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:40:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:40:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:40:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:40:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:40:10 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:40:10 --> Final output sent to browser
DEBUG - 2013-08-05 12:40:10 --> Total execution time: 0.4922
DEBUG - 2013-08-05 12:40:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:40:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:40:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:40:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:40:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:40:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:40:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:40:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:40:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:40:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:40:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:40:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:40:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:40:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:40:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:40:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:40:10 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 12:40:10 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:43:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:43:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Output Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Security Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Input Class Initialized
DEBUG - 2013-08-05 12:43:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:43:17 --> XSS Filtering completed
DEBUG - 2013-08-05 12:43:17 --> CRSF cookie Set
DEBUG - 2013-08-05 12:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:43:17 --> Language Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Loader Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:43:17 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:43:17 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Session Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:43:17 --> Session routines successfully run
DEBUG - 2013-08-05 12:43:17 --> Controller Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:43:17 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:43:17 --> Final output sent to browser
DEBUG - 2013-08-05 12:43:17 --> Total execution time: 0.4997
DEBUG - 2013-08-05 12:43:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Config Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:43:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:43:17 --> URI Class Initialized
DEBUG - 2013-08-05 12:43:17 --> Router Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Router Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Output Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Output Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Security Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Security Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Input Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Input Class Initialized
DEBUG - 2013-08-05 12:43:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:43:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:43:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:43:18 --> XSS Filtering completed
DEBUG - 2013-08-05 12:43:18 --> CRSF cookie Set
DEBUG - 2013-08-05 12:43:18 --> CRSF cookie Set
DEBUG - 2013-08-05 12:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:43:18 --> Language Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Language Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Loader Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Loader Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:43:18 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:43:18 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:43:18 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:43:18 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Session Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Session Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:43:18 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:43:18 --> Session routines successfully run
DEBUG - 2013-08-05 12:43:18 --> Session routines successfully run
DEBUG - 2013-08-05 12:43:18 --> Controller Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Controller Class Initialized
DEBUG - 2013-08-05 12:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:43:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:43:18 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 12:43:18 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:49:09 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:09 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:09 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:09 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:09 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:09 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:09 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:09 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:09 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:49:10 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 12:49:10 --> Final output sent to browser
DEBUG - 2013-08-05 12:49:10 --> Total execution time: 0.4698
DEBUG - 2013-08-05 12:49:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:49:10 --> Final output sent to browser
DEBUG - 2013-08-05 12:49:10 --> Total execution time: 0.4528
DEBUG - 2013-08-05 12:49:13 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:13 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:13 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:13 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:13 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:13 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:13 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:49:14 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:49:14 --> Final output sent to browser
DEBUG - 2013-08-05 12:49:14 --> Total execution time: 0.5170
DEBUG - 2013-08-05 12:49:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:14 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:14 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:14 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:14 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:14 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:49:14 --> Session routines successfully run
ERROR - 2013-08-05 12:49:14 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:49:14 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:49:14 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 12:49:47 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:47 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:47 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:47 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:47 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:47 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:47 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:47 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:47 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:47 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:49:47 --> 404 Page Not Found --> teacher/rgade
DEBUG - 2013-08-05 12:49:49 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:49 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:49:49 --> 404 Page Not Found --> teacher/grade
DEBUG - 2013-08-05 12:49:51 --> Config Class Initialized
DEBUG - 2013-08-05 12:49:51 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:49:51 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:49:51 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:49:52 --> URI Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Router Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Output Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Security Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Input Class Initialized
DEBUG - 2013-08-05 12:49:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:52 --> XSS Filtering completed
DEBUG - 2013-08-05 12:49:52 --> CRSF cookie Set
DEBUG - 2013-08-05 12:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:49:52 --> Language Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Loader Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:49:52 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:49:52 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Session Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:49:52 --> Session routines successfully run
DEBUG - 2013-08-05 12:49:52 --> Controller Class Initialized
DEBUG - 2013-08-05 12:49:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:49:52 --> 404 Page Not Found --> teacher/grades
DEBUG - 2013-08-05 12:50:19 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:19 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:19 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:19 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:19 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:19 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:19 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:19 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:19 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:19 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:50:19 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:50:19 --> Final output sent to browser
DEBUG - 2013-08-05 12:50:19 --> Total execution time: 0.4935
DEBUG - 2013-08-05 12:50:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:20 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:20 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/logoutsign.png
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:50:21 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Hooks Class Initialized
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:50:21 --> Config Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:21 --> Utf8 Class Initialized
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/pisaralogo2.png
DEBUG - 2013-08-05 12:50:21 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:50:21 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:21 --> URI Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Router Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Output Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Security Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Input Class Initialized
DEBUG - 2013-08-05 12:50:21 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:21 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:21 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:21 --> XSS Filtering completed
DEBUG - 2013-08-05 12:50:21 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:21 --> CRSF cookie Set
DEBUG - 2013-08-05 12:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:50:21 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Language Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Loader Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:50:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:50:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/d66.png
ERROR - 2013-08-05 12:50:21 --> 404 Page Not Found --> teacher/done.png
DEBUG - 2013-08-05 12:51:10 --> Config Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:51:10 --> URI Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Router Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Output Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Security Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Input Class Initialized
DEBUG - 2013-08-05 12:51:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:51:10 --> XSS Filtering completed
DEBUG - 2013-08-05 12:51:10 --> CRSF cookie Set
DEBUG - 2013-08-05 12:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:51:10 --> Language Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Loader Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:51:10 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:51:10 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Session Class Initialized
DEBUG - 2013-08-05 12:51:10 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:51:10 --> Session routines successfully run
DEBUG - 2013-08-05 12:51:10 --> Controller Class Initialized
DEBUG - 2013-08-05 12:51:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:51:11 --> 404 Page Not Found --> teacher/teachergrade.html
DEBUG - 2013-08-05 12:52:38 --> Config Class Initialized
DEBUG - 2013-08-05 12:52:38 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:52:38 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:52:38 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:52:38 --> URI Class Initialized
DEBUG - 2013-08-05 12:52:38 --> Router Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Output Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Security Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Input Class Initialized
DEBUG - 2013-08-05 12:52:39 --> XSS Filtering completed
DEBUG - 2013-08-05 12:52:39 --> XSS Filtering completed
DEBUG - 2013-08-05 12:52:39 --> CRSF cookie Set
DEBUG - 2013-08-05 12:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:52:39 --> Language Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Loader Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:52:39 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:52:39 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Session Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:52:39 --> Session routines successfully run
DEBUG - 2013-08-05 12:52:39 --> Controller Class Initialized
DEBUG - 2013-08-05 12:52:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:52:39 --> 404 Page Not Found --> teacher/teachergrade.html
DEBUG - 2013-08-05 12:53:44 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:44 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:44 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:44 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:44 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:44 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:44 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:44 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:44 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:45 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:45 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:45 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:45 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:45 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 12:53:45 --> Final output sent to browser
DEBUG - 2013-08-05 12:53:45 --> Total execution time: 0.5130
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:48 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:48 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:48 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:48 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:48 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:48 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:53:48 --> Final output sent to browser
DEBUG - 2013-08-05 12:53:48 --> Total execution time: 0.4792
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:48 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:49 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:49 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:49 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:49 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:49 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:49 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:49 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Controller Class Initialized
ERROR - 2013-08-05 12:53:49 --> 404 Page Not Found --> teacher/logoutsign.png
ERROR - 2013-08-05 12:53:49 --> 404 Page Not Found --> teacher/d22.png
ERROR - 2013-08-05 12:53:49 --> 404 Page Not Found --> teacher/pisaralogo2.png
DEBUG - 2013-08-05 12:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:49 --> Config Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:49 --> Config Class Initialized
ERROR - 2013-08-05 12:53:49 --> 404 Page Not Found --> teacher/d33.png
ERROR - 2013-08-05 12:53:49 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:53:49 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Hooks Class Initialized
ERROR - 2013-08-05 12:53:49 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:53:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:49 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:53:49 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:49 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:53:49 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:49 --> URI Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Router Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:49 --> Output Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:50 --> Security Class Initialized
DEBUG - 2013-08-05 12:53:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:50 --> Input Class Initialized
DEBUG - 2013-08-05 12:53:50 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:50 --> XSS Filtering completed
DEBUG - 2013-08-05 12:53:50 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:50 --> CRSF cookie Set
DEBUG - 2013-08-05 12:53:50 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:53:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:50 --> Language Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:50 --> Loader Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:53:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:53:50 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:50 --> Session Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:50 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:53:50 --> Controller Class Initialized
DEBUG - 2013-08-05 12:53:50 --> Session routines successfully run
DEBUG - 2013-08-05 12:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:53:50 --> Controller Class Initialized
ERROR - 2013-08-05 12:53:50 --> 404 Page Not Found --> teacher/done.png
DEBUG - 2013-08-05 12:53:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:53:50 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:55:03 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:03 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:03 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:03 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:03 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:03 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:03 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:03 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:04 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:04 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:04 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:04 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:55:04 --> Final output sent to browser
DEBUG - 2013-08-05 12:55:04 --> Total execution time: 0.5039
DEBUG - 2013-08-05 12:55:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:04 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:04 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:05 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:05 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:05 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:05 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:05 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:05 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:05 --> Controller Class Initialized
ERROR - 2013-08-05 12:55:05 --> 404 Page Not Found --> teacher/d55.png
ERROR - 2013-08-05 12:55:05 --> 404 Page Not Found --> teacher/done.png
ERROR - 2013-08-05 12:55:05 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:55:05 --> 404 Page Not Found --> teacher/d22.png
ERROR - 2013-08-05 12:55:05 --> 404 Page Not Found --> teacher/d33.png
ERROR - 2013-08-05 12:55:05 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:55:11 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:11 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:11 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:11 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:11 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:11 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:11 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:11 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:11 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:11 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:11 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:55:11 --> Final output sent to browser
DEBUG - 2013-08-05 12:55:11 --> Total execution time: 0.5003
DEBUG - 2013-08-05 12:55:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:12 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:12 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:12 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:12 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:12 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:12 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:12 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:13 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:13 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:13 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:13 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:13 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:13 --> Session routines successfully run
ERROR - 2013-08-05 12:55:13 --> 404 Page Not Found --> teacher/done.png
DEBUG - 2013-08-05 12:55:13 --> Controller Class Initialized
ERROR - 2013-08-05 12:55:13 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:13 --> Controller Class Initialized
ERROR - 2013-08-05 12:55:13 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:55:13 --> 404 Page Not Found --> teacher/d55.png
ERROR - 2013-08-05 12:55:13 --> 404 Page Not Found --> teacher/d22.png
ERROR - 2013-08-05 12:55:13 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:55:19 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:19 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:19 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:19 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:19 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:19 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:19 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:19 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:19 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:19 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:19 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:55:19 --> Final output sent to browser
DEBUG - 2013-08-05 12:55:19 --> Total execution time: 0.5173
DEBUG - 2013-08-05 12:55:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:20 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:20 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:20 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:20 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:20 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:21 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:21 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:21 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:55:21 --> 404 Page Not Found --> teacher/done.png
ERROR - 2013-08-05 12:55:21 --> 404 Page Not Found --> teacher/d11b.png
DEBUG - 2013-08-05 12:55:21 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:55:21 --> 404 Page Not Found --> teacher/d55.png
DEBUG - 2013-08-05 12:55:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:55:21 --> 404 Page Not Found --> teacher/d66.png
DEBUG - 2013-08-05 12:55:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:55:21 --> 404 Page Not Found --> teacher/d33.png
ERROR - 2013-08-05 12:55:21 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:55:58 --> Config Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:55:59 --> URI Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Router Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Output Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Security Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Input Class Initialized
DEBUG - 2013-08-05 12:55:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:59 --> XSS Filtering completed
DEBUG - 2013-08-05 12:55:59 --> CRSF cookie Set
DEBUG - 2013-08-05 12:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:55:59 --> Language Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Loader Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:55:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:55:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Session Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:55:59 --> Session routines successfully run
DEBUG - 2013-08-05 12:55:59 --> Controller Class Initialized
DEBUG - 2013-08-05 12:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:55:59 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:55:59 --> Final output sent to browser
DEBUG - 2013-08-05 12:55:59 --> Total execution time: 0.5171
DEBUG - 2013-08-05 12:56:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:00 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:00 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:00 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:00 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:00 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:00 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:01 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:01 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:56:01 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:56:01 --> 404 Page Not Found --> teacher/done.png
ERROR - 2013-08-05 12:56:01 --> 404 Page Not Found --> teacher/d11b.png
ERROR - 2013-08-05 12:56:01 --> 404 Page Not Found --> teacher/d66.png
ERROR - 2013-08-05 12:56:01 --> 404 Page Not Found --> teacher/d22.png
DEBUG - 2013-08-05 12:56:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:56:01 --> 404 Page Not Found --> teacher/d55.png
ERROR - 2013-08-05 12:56:01 --> 404 Page Not Found --> teacher/d33.png
DEBUG - 2013-08-05 12:56:36 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:36 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:36 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:36 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:36 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:36 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:36 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:36 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:36 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:36 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:37 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:37 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:37 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:37 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:56:37 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:56:37 --> Final output sent to browser
DEBUG - 2013-08-05 12:56:37 --> Total execution time: 0.5290
DEBUG - 2013-08-05 12:56:37 --> Config Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:56:37 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:56:37 --> URI Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Router Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Output Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Security Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Input Class Initialized
DEBUG - 2013-08-05 12:56:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:37 --> XSS Filtering completed
DEBUG - 2013-08-05 12:56:37 --> CRSF cookie Set
DEBUG - 2013-08-05 12:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:56:37 --> Language Class Initialized
DEBUG - 2013-08-05 12:56:37 --> Loader Class Initialized
DEBUG - 2013-08-05 12:56:38 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:56:38 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:56:38 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:56:38 --> Session Class Initialized
DEBUG - 2013-08-05 12:56:38 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:56:38 --> Session routines successfully run
DEBUG - 2013-08-05 12:56:38 --> Controller Class Initialized
DEBUG - 2013-08-05 12:56:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:56:38 --> 404 Page Not Found --> teacher/done.png
DEBUG - 2013-08-05 12:58:25 --> Config Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:58:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:58:25 --> URI Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Router Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Output Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Security Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Input Class Initialized
DEBUG - 2013-08-05 12:58:25 --> XSS Filtering completed
DEBUG - 2013-08-05 12:58:25 --> XSS Filtering completed
DEBUG - 2013-08-05 12:58:25 --> CRSF cookie Set
DEBUG - 2013-08-05 12:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:58:25 --> Language Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Loader Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:58:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:58:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Session Class Initialized
DEBUG - 2013-08-05 12:58:25 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:58:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:58:26 --> Controller Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:58:26 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:58:26 --> Final output sent to browser
DEBUG - 2013-08-05 12:58:26 --> Total execution time: 0.5467
DEBUG - 2013-08-05 12:58:26 --> Config Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:58:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:58:26 --> URI Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Router Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Output Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Security Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Input Class Initialized
DEBUG - 2013-08-05 12:58:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:58:26 --> XSS Filtering completed
DEBUG - 2013-08-05 12:58:26 --> CRSF cookie Set
DEBUG - 2013-08-05 12:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:58:26 --> Language Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Loader Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:58:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:58:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Session Class Initialized
DEBUG - 2013-08-05 12:58:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:58:26 --> Session routines successfully run
DEBUG - 2013-08-05 12:58:27 --> Controller Class Initialized
DEBUG - 2013-08-05 12:58:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:58:27 --> 404 Page Not Found --> teacher/done.png
DEBUG - 2013-08-05 12:59:21 --> Config Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:59:21 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:59:21 --> URI Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Router Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Output Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Security Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Input Class Initialized
DEBUG - 2013-08-05 12:59:21 --> XSS Filtering completed
DEBUG - 2013-08-05 12:59:21 --> XSS Filtering completed
DEBUG - 2013-08-05 12:59:21 --> CRSF cookie Set
DEBUG - 2013-08-05 12:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:59:21 --> Language Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Loader Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:59:21 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:59:21 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Session Class Initialized
DEBUG - 2013-08-05 12:59:21 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:59:22 --> Session routines successfully run
DEBUG - 2013-08-05 12:59:22 --> Controller Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 12:59:22 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 12:59:22 --> Final output sent to browser
DEBUG - 2013-08-05 12:59:22 --> Total execution time: 0.5494
DEBUG - 2013-08-05 12:59:22 --> Config Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Hooks Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Utf8 Class Initialized
DEBUG - 2013-08-05 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 12:59:22 --> URI Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Router Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Output Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Security Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Input Class Initialized
DEBUG - 2013-08-05 12:59:22 --> XSS Filtering completed
DEBUG - 2013-08-05 12:59:22 --> XSS Filtering completed
DEBUG - 2013-08-05 12:59:22 --> CRSF cookie Set
DEBUG - 2013-08-05 12:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 12:59:22 --> Language Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Loader Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Helper loaded: url_helper
DEBUG - 2013-08-05 12:59:22 --> Helper loaded: form_helper
DEBUG - 2013-08-05 12:59:22 --> Database Driver Class Initialized
DEBUG - 2013-08-05 12:59:22 --> Session Class Initialized
DEBUG - 2013-08-05 12:59:23 --> Helper loaded: string_helper
DEBUG - 2013-08-05 12:59:23 --> Session routines successfully run
DEBUG - 2013-08-05 12:59:23 --> Controller Class Initialized
DEBUG - 2013-08-05 12:59:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 12:59:23 --> 404 Page Not Found --> teacher/done.png
DEBUG - 2013-08-05 13:00:20 --> Config Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:00:20 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:00:20 --> URI Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Router Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Output Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Security Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Input Class Initialized
DEBUG - 2013-08-05 13:00:20 --> XSS Filtering completed
DEBUG - 2013-08-05 13:00:20 --> XSS Filtering completed
DEBUG - 2013-08-05 13:00:20 --> CRSF cookie Set
DEBUG - 2013-08-05 13:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:00:20 --> Language Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Loader Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:00:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:00:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Session Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:00:20 --> Session routines successfully run
DEBUG - 2013-08-05 13:00:20 --> Controller Class Initialized
DEBUG - 2013-08-05 13:00:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:00:20 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 13:00:20 --> Final output sent to browser
DEBUG - 2013-08-05 13:00:20 --> Total execution time: 0.5398
DEBUG - 2013-08-05 13:00:26 --> Config Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:00:26 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:00:26 --> URI Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Router Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Output Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Security Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Input Class Initialized
DEBUG - 2013-08-05 13:00:26 --> XSS Filtering completed
DEBUG - 2013-08-05 13:00:26 --> XSS Filtering completed
DEBUG - 2013-08-05 13:00:26 --> CRSF cookie Set
DEBUG - 2013-08-05 13:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:00:26 --> Language Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Loader Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:00:26 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:00:26 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Session Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:00:26 --> Session routines successfully run
DEBUG - 2013-08-05 13:00:26 --> Controller Class Initialized
DEBUG - 2013-08-05 13:00:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:00:26 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 13:00:26 --> Final output sent to browser
DEBUG - 2013-08-05 13:00:26 --> Total execution time: 0.5640
DEBUG - 2013-08-05 13:00:41 --> Config Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:00:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:00:41 --> URI Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Router Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Output Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Security Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Input Class Initialized
DEBUG - 2013-08-05 13:00:41 --> XSS Filtering completed
DEBUG - 2013-08-05 13:00:41 --> XSS Filtering completed
DEBUG - 2013-08-05 13:00:41 --> CRSF cookie Set
DEBUG - 2013-08-05 13:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:00:41 --> Language Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Loader Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:00:41 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:00:41 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Session Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:00:41 --> Session routines successfully run
DEBUG - 2013-08-05 13:00:41 --> Controller Class Initialized
DEBUG - 2013-08-05 13:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:00:41 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 13:00:41 --> Final output sent to browser
DEBUG - 2013-08-05 13:00:41 --> Total execution time: 0.5534
DEBUG - 2013-08-05 13:28:54 --> Config Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:28:54 --> URI Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Router Class Initialized
DEBUG - 2013-08-05 13:28:54 --> No URI present. Default controller set.
DEBUG - 2013-08-05 13:28:54 --> Output Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Security Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Input Class Initialized
DEBUG - 2013-08-05 13:28:54 --> XSS Filtering completed
DEBUG - 2013-08-05 13:28:54 --> XSS Filtering completed
DEBUG - 2013-08-05 13:28:54 --> CRSF cookie Set
DEBUG - 2013-08-05 13:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:28:54 --> Language Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Loader Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:28:54 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:28:54 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Session Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:28:54 --> Session routines successfully run
DEBUG - 2013-08-05 13:28:54 --> Controller Class Initialized
DEBUG - 2013-08-05 13:28:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:28:54 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:28:54 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 13:28:54 --> Final output sent to browser
DEBUG - 2013-08-05 13:28:54 --> Total execution time: 0.5864
DEBUG - 2013-08-05 13:30:55 --> Config Class Initialized
DEBUG - 2013-08-05 13:30:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:30:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:30:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:30:55 --> URI Class Initialized
DEBUG - 2013-08-05 13:30:55 --> Router Class Initialized
DEBUG - 2013-08-05 13:30:55 --> No URI present. Default controller set.
DEBUG - 2013-08-05 13:30:55 --> Output Class Initialized
DEBUG - 2013-08-05 13:30:55 --> Security Class Initialized
DEBUG - 2013-08-05 13:30:55 --> Input Class Initialized
DEBUG - 2013-08-05 13:30:55 --> XSS Filtering completed
DEBUG - 2013-08-05 13:30:55 --> XSS Filtering completed
DEBUG - 2013-08-05 13:30:56 --> CRSF cookie Set
DEBUG - 2013-08-05 13:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:30:56 --> Language Class Initialized
DEBUG - 2013-08-05 13:30:56 --> Loader Class Initialized
DEBUG - 2013-08-05 13:30:56 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:30:56 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:30:56 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:30:56 --> Session Class Initialized
DEBUG - 2013-08-05 13:30:56 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:30:56 --> Session routines successfully run
DEBUG - 2013-08-05 13:30:56 --> Controller Class Initialized
DEBUG - 2013-08-05 13:30:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:30:56 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:30:56 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 13:30:56 --> Final output sent to browser
DEBUG - 2013-08-05 13:30:56 --> Total execution time: 0.5788
DEBUG - 2013-08-05 13:31:25 --> Config Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:31:25 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:31:25 --> URI Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Router Class Initialized
DEBUG - 2013-08-05 13:31:25 --> No URI present. Default controller set.
DEBUG - 2013-08-05 13:31:25 --> Output Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Security Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Input Class Initialized
DEBUG - 2013-08-05 13:31:25 --> XSS Filtering completed
DEBUG - 2013-08-05 13:31:25 --> XSS Filtering completed
DEBUG - 2013-08-05 13:31:25 --> CRSF cookie Set
DEBUG - 2013-08-05 13:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:31:25 --> Language Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Loader Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:31:25 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:31:25 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:31:25 --> Session Class Initialized
DEBUG - 2013-08-05 13:31:26 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:31:26 --> Session routines successfully run
DEBUG - 2013-08-05 13:31:26 --> Controller Class Initialized
DEBUG - 2013-08-05 13:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:31:26 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:31:26 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 13:31:26 --> Final output sent to browser
DEBUG - 2013-08-05 13:31:26 --> Total execution time: 0.5765
DEBUG - 2013-08-05 13:31:41 --> Config Class Initialized
DEBUG - 2013-08-05 13:31:41 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:31:41 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:31:41 --> URI Class Initialized
DEBUG - 2013-08-05 13:31:41 --> Router Class Initialized
DEBUG - 2013-08-05 13:31:41 --> No URI present. Default controller set.
DEBUG - 2013-08-05 13:31:41 --> Output Class Initialized
DEBUG - 2013-08-05 13:31:41 --> Security Class Initialized
DEBUG - 2013-08-05 13:31:41 --> Input Class Initialized
DEBUG - 2013-08-05 13:31:41 --> XSS Filtering completed
DEBUG - 2013-08-05 13:31:41 --> XSS Filtering completed
DEBUG - 2013-08-05 13:31:41 --> CRSF cookie Set
DEBUG - 2013-08-05 13:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:31:42 --> Language Class Initialized
DEBUG - 2013-08-05 13:31:42 --> Loader Class Initialized
DEBUG - 2013-08-05 13:31:42 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:31:42 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:31:42 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:31:42 --> Session Class Initialized
DEBUG - 2013-08-05 13:31:42 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:31:42 --> Session routines successfully run
DEBUG - 2013-08-05 13:31:42 --> Controller Class Initialized
DEBUG - 2013-08-05 13:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:31:42 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:31:42 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 13:31:42 --> Final output sent to browser
DEBUG - 2013-08-05 13:31:42 --> Total execution time: 0.5973
DEBUG - 2013-08-05 13:32:06 --> Config Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:32:06 --> URI Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Router Class Initialized
DEBUG - 2013-08-05 13:32:06 --> No URI present. Default controller set.
DEBUG - 2013-08-05 13:32:06 --> Output Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Security Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Input Class Initialized
DEBUG - 2013-08-05 13:32:06 --> XSS Filtering completed
DEBUG - 2013-08-05 13:32:06 --> XSS Filtering completed
DEBUG - 2013-08-05 13:32:06 --> CRSF cookie Set
DEBUG - 2013-08-05 13:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:32:06 --> Language Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Loader Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:32:06 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:32:06 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Session Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:32:06 --> Session routines successfully run
DEBUG - 2013-08-05 13:32:06 --> Controller Class Initialized
DEBUG - 2013-08-05 13:32:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:32:06 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:32:07 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 13:32:07 --> Final output sent to browser
DEBUG - 2013-08-05 13:32:07 --> Total execution time: 0.5812
DEBUG - 2013-08-05 13:33:47 --> Config Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:33:47 --> URI Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Router Class Initialized
DEBUG - 2013-08-05 13:33:47 --> No URI present. Default controller set.
DEBUG - 2013-08-05 13:33:47 --> Output Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Security Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Input Class Initialized
DEBUG - 2013-08-05 13:33:47 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:47 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:47 --> CRSF cookie Set
DEBUG - 2013-08-05 13:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:33:47 --> Language Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Loader Class Initialized
DEBUG - 2013-08-05 13:33:47 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:33:48 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:33:48 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:33:48 --> Session Class Initialized
DEBUG - 2013-08-05 13:33:48 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:33:48 --> Session routines successfully run
DEBUG - 2013-08-05 13:33:48 --> Controller Class Initialized
DEBUG - 2013-08-05 13:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:33:48 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:33:48 --> File loaded: application/views/welcome_message.php
DEBUG - 2013-08-05 13:33:48 --> Final output sent to browser
DEBUG - 2013-08-05 13:33:48 --> Total execution time: 0.6068
DEBUG - 2013-08-05 13:33:58 --> Config Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:33:58 --> URI Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Router Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Output Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Security Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Input Class Initialized
DEBUG - 2013-08-05 13:33:58 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:58 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:58 --> CRSF cookie Set
DEBUG - 2013-08-05 13:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:33:58 --> Language Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Loader Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:33:58 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:33:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Session Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:33:58 --> Session routines successfully run
DEBUG - 2013-08-05 13:33:58 --> Controller Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:33:58 --> Config Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:33:58 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:33:59 --> URI Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Router Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Output Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Security Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Input Class Initialized
DEBUG - 2013-08-05 13:33:59 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:59 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:59 --> CRSF cookie Set
DEBUG - 2013-08-05 13:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:33:59 --> Language Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Loader Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:33:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:33:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Session Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:33:59 --> Session routines successfully run
DEBUG - 2013-08-05 13:33:59 --> Controller Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:33:59 --> Config Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:33:59 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:33:59 --> URI Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Router Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Output Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Security Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Input Class Initialized
DEBUG - 2013-08-05 13:33:59 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:59 --> XSS Filtering completed
DEBUG - 2013-08-05 13:33:59 --> CRSF cookie Set
DEBUG - 2013-08-05 13:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:33:59 --> Language Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Loader Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:33:59 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:33:59 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Session Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:33:59 --> Session routines successfully run
DEBUG - 2013-08-05 13:33:59 --> Controller Class Initialized
DEBUG - 2013-08-05 13:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:33:59 --> File loaded: application/views/login.php
DEBUG - 2013-08-05 13:33:59 --> Final output sent to browser
DEBUG - 2013-08-05 13:34:00 --> Total execution time: 0.5413
DEBUG - 2013-08-05 13:34:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:00 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:00 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:01 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:01 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:01 --> Controller Class Initialized
ERROR - 2013-08-05 13:34:01 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:01 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Controller Class Initialized
ERROR - 2013-08-05 13:34:01 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 13:34:01 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Config Class Initialized
ERROR - 2013-08-05 13:34:01 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 13:34:01 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Hooks Class Initialized
ERROR - 2013-08-05 13:34:01 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:34:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:34:01 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:01 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:01 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:02 --> XSS Filtering completed
DEBUG - 2013-08-05 13:34:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:02 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:02 --> CRSF cookie Set
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:34:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:34:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:34:02 --> Session routines successfully run
ERROR - 2013-08-05 13:34:02 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:02 --> Helper loaded: string_helper
ERROR - 2013-08-05 13:34:02 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:02 --> Session routines successfully run
DEBUG - 2013-08-05 13:34:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session routines successfully run
ERROR - 2013-08-05 13:34:02 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:34:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:34:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 13:34:02 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 13:34:02 --> 404 Page Not Found --> main/js
ERROR - 2013-08-05 13:34:02 --> 404 Page Not Found --> main/js
DEBUG - 2013-08-05 13:38:29 --> Config Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:38:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:38:29 --> URI Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Router Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Output Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Security Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Input Class Initialized
DEBUG - 2013-08-05 13:38:29 --> XSS Filtering completed
DEBUG - 2013-08-05 13:38:29 --> XSS Filtering completed
DEBUG - 2013-08-05 13:38:29 --> CRSF cookie Set
DEBUG - 2013-08-05 13:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:38:29 --> Language Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Loader Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:38:29 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:38:29 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Session Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:38:29 --> Session routines successfully run
DEBUG - 2013-08-05 13:38:29 --> Controller Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:38:29 --> File loaded: application/views/new_login.php
DEBUG - 2013-08-05 13:38:29 --> Final output sent to browser
DEBUG - 2013-08-05 13:38:29 --> Total execution time: 0.5572
DEBUG - 2013-08-05 13:38:29 --> Config Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Config Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:38:29 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:38:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:38:29 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:38:30 --> URI Class Initialized
DEBUG - 2013-08-05 13:38:30 --> URI Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Router Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Router Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Output Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Output Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Security Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Security Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Input Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Input Class Initialized
DEBUG - 2013-08-05 13:38:30 --> XSS Filtering completed
DEBUG - 2013-08-05 13:38:30 --> XSS Filtering completed
DEBUG - 2013-08-05 13:38:30 --> XSS Filtering completed
DEBUG - 2013-08-05 13:38:30 --> XSS Filtering completed
DEBUG - 2013-08-05 13:38:30 --> CRSF cookie Set
DEBUG - 2013-08-05 13:38:30 --> CRSF cookie Set
DEBUG - 2013-08-05 13:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:38:30 --> Language Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Language Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Loader Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Loader Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:38:30 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:38:30 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:38:30 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:38:30 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Session Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Session Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:38:30 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:38:30 --> Session routines successfully run
DEBUG - 2013-08-05 13:38:30 --> Session routines successfully run
DEBUG - 2013-08-05 13:38:30 --> Controller Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Controller Class Initialized
DEBUG - 2013-08-05 13:38:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 13:38:30 --> 404 Page Not Found --> main/loadinglogo.png
ERROR - 2013-08-05 13:38:30 --> 404 Page Not Found --> main/makatimedlogo.png
DEBUG - 2013-08-05 13:40:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:40:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:40:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:40:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Loader Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:40:00 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:40:00 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Session Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:40:00 --> Session routines successfully run
DEBUG - 2013-08-05 13:40:00 --> Controller Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:40:00 --> File loaded: application/views/new_login.php
DEBUG - 2013-08-05 13:40:00 --> Final output sent to browser
DEBUG - 2013-08-05 13:40:00 --> Total execution time: 0.5674
DEBUG - 2013-08-05 13:40:00 --> Config Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:40:00 --> URI Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Router Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Output Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Security Class Initialized
DEBUG - 2013-08-05 13:40:00 --> Input Class Initialized
DEBUG - 2013-08-05 13:40:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:00 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:00 --> CRSF cookie Set
DEBUG - 2013-08-05 13:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:40:00 --> Language Class Initialized
DEBUG - 2013-08-05 13:40:01 --> Loader Class Initialized
DEBUG - 2013-08-05 13:40:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:40:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:40:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:40:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:40:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:40:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:40:01 --> Controller Class Initialized
DEBUG - 2013-08-05 13:40:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 13:40:01 --> 404 Page Not Found --> main/loadinglogo.png
DEBUG - 2013-08-05 13:40:19 --> Config Class Initialized
DEBUG - 2013-08-05 13:40:19 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:40:19 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:40:19 --> URI Class Initialized
DEBUG - 2013-08-05 13:40:19 --> Router Class Initialized
DEBUG - 2013-08-05 13:40:19 --> Output Class Initialized
DEBUG - 2013-08-05 13:40:19 --> Security Class Initialized
DEBUG - 2013-08-05 13:40:19 --> Input Class Initialized
DEBUG - 2013-08-05 13:40:19 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:19 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:19 --> CRSF cookie Set
DEBUG - 2013-08-05 13:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:40:20 --> Language Class Initialized
DEBUG - 2013-08-05 13:40:20 --> Loader Class Initialized
DEBUG - 2013-08-05 13:40:20 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:40:20 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:40:20 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:40:20 --> Session Class Initialized
DEBUG - 2013-08-05 13:40:20 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:40:20 --> Session routines successfully run
DEBUG - 2013-08-05 13:40:20 --> Controller Class Initialized
DEBUG - 2013-08-05 13:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:40:20 --> File loaded: application/views/new_login.php
DEBUG - 2013-08-05 13:40:20 --> Final output sent to browser
DEBUG - 2013-08-05 13:40:20 --> Total execution time: 0.5984
DEBUG - 2013-08-05 13:40:23 --> Config Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:40:23 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:40:23 --> URI Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Router Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Output Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Security Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Input Class Initialized
DEBUG - 2013-08-05 13:40:23 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:23 --> XSS Filtering completed
DEBUG - 2013-08-05 13:40:23 --> CRSF cookie Set
DEBUG - 2013-08-05 13:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:40:23 --> Language Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Loader Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:40:23 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:40:23 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Session Class Initialized
DEBUG - 2013-08-05 13:40:23 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:40:23 --> Session routines successfully run
DEBUG - 2013-08-05 13:40:24 --> Controller Class Initialized
DEBUG - 2013-08-05 13:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:40:24 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:40:24 --> Final output sent to browser
DEBUG - 2013-08-05 13:40:24 --> Total execution time: 0.5602
DEBUG - 2013-08-05 13:41:46 --> Config Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:41:46 --> URI Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Router Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Output Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Security Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Input Class Initialized
DEBUG - 2013-08-05 13:41:46 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:46 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:46 --> CRSF cookie Set
DEBUG - 2013-08-05 13:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:41:46 --> Language Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Loader Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:41:46 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:41:46 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Session Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:41:46 --> Session routines successfully run
DEBUG - 2013-08-05 13:41:46 --> Controller Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:41:46 --> Config Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:41:46 --> URI Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Router Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Output Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Security Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Input Class Initialized
DEBUG - 2013-08-05 13:41:46 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:46 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:46 --> CRSF cookie Set
DEBUG - 2013-08-05 13:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:41:46 --> Language Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Loader Class Initialized
DEBUG - 2013-08-05 13:41:46 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:41:46 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:41:46 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Session Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:41:47 --> Session routines successfully run
DEBUG - 2013-08-05 13:41:47 --> Controller Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:41:47 --> Config Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:41:47 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:41:47 --> URI Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Router Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Output Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Security Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Input Class Initialized
DEBUG - 2013-08-05 13:41:47 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:47 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:47 --> CRSF cookie Set
DEBUG - 2013-08-05 13:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:41:47 --> Language Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Loader Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:41:47 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:41:47 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Session Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:41:47 --> Session routines successfully run
DEBUG - 2013-08-05 13:41:47 --> Controller Class Initialized
DEBUG - 2013-08-05 13:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:41:47 --> File loaded: application/views/new_login.php
DEBUG - 2013-08-05 13:41:47 --> Final output sent to browser
DEBUG - 2013-08-05 13:41:47 --> Total execution time: 0.5703
DEBUG - 2013-08-05 13:41:55 --> Config Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:41:55 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:41:55 --> URI Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Router Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Output Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Security Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Input Class Initialized
DEBUG - 2013-08-05 13:41:55 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:55 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:55 --> CRSF cookie Set
DEBUG - 2013-08-05 13:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:41:55 --> Language Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Loader Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:41:55 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:41:55 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Session Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:41:55 --> Session routines successfully run
DEBUG - 2013-08-05 13:41:55 --> Controller Class Initialized
DEBUG - 2013-08-05 13:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:41:55 --> File loaded: application/views/dashboard.php
DEBUG - 2013-08-05 13:41:55 --> Final output sent to browser
DEBUG - 2013-08-05 13:41:55 --> Total execution time: 0.5555
DEBUG - 2013-08-05 13:41:56 --> Config Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:41:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:41:57 --> URI Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Router Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Output Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Security Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Input Class Initialized
DEBUG - 2013-08-05 13:41:57 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:57 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:57 --> CRSF cookie Set
DEBUG - 2013-08-05 13:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:41:57 --> Language Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Loader Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:41:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:41:57 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Session Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:41:57 --> Session routines successfully run
DEBUG - 2013-08-05 13:41:57 --> Controller Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:41:57 --> File loaded: application/views/load2.php
DEBUG - 2013-08-05 13:41:57 --> Final output sent to browser
DEBUG - 2013-08-05 13:41:57 --> Total execution time: 0.5696
DEBUG - 2013-08-05 13:41:57 --> Config Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:41:57 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:41:57 --> URI Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Router Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Output Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Security Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Input Class Initialized
DEBUG - 2013-08-05 13:41:57 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:57 --> XSS Filtering completed
DEBUG - 2013-08-05 13:41:57 --> CRSF cookie Set
DEBUG - 2013-08-05 13:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:41:57 --> Language Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Loader Class Initialized
DEBUG - 2013-08-05 13:41:57 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:41:57 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:41:58 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:41:58 --> Session Class Initialized
DEBUG - 2013-08-05 13:41:58 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:41:58 --> Session routines successfully run
DEBUG - 2013-08-05 13:41:58 --> Controller Class Initialized
DEBUG - 2013-08-05 13:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:41:58 --> Final output sent to browser
DEBUG - 2013-08-05 13:41:58 --> Total execution time: 0.5304
DEBUG - 2013-08-05 13:42:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:42:01 --> URI Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Router Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Output Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Security Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Input Class Initialized
DEBUG - 2013-08-05 13:42:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:01 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:01 --> CRSF cookie Set
DEBUG - 2013-08-05 13:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:42:01 --> Language Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Loader Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:42:01 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:42:01 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Session Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:42:01 --> Session routines successfully run
DEBUG - 2013-08-05 13:42:01 --> Controller Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:42:01 --> File loaded: application/views/teacher/class.php
DEBUG - 2013-08-05 13:42:01 --> Final output sent to browser
DEBUG - 2013-08-05 13:42:01 --> Total execution time: 0.5824
DEBUG - 2013-08-05 13:42:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Config Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:42:01 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:42:02 --> URI Class Initialized
DEBUG - 2013-08-05 13:42:02 --> URI Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Router Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Router Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Output Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Output Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Security Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Security Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Input Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Input Class Initialized
DEBUG - 2013-08-05 13:42:02 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:02 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:02 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:02 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:02 --> CRSF cookie Set
DEBUG - 2013-08-05 13:42:02 --> CRSF cookie Set
DEBUG - 2013-08-05 13:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:42:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Language Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Loader Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:42:02 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:42:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:42:02 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:42:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Session Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:42:02 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:42:02 --> Session routines successfully run
DEBUG - 2013-08-05 13:42:02 --> Session routines successfully run
DEBUG - 2013-08-05 13:42:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Controller Class Initialized
DEBUG - 2013-08-05 13:42:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:42:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2013-08-05 13:42:02 --> 404 Page Not Found --> teacher/js
ERROR - 2013-08-05 13:42:02 --> 404 Page Not Found --> teacher/js
DEBUG - 2013-08-05 13:42:07 --> Config Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:42:07 --> URI Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Router Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Output Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Security Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Input Class Initialized
DEBUG - 2013-08-05 13:42:07 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:07 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:07 --> CRSF cookie Set
DEBUG - 2013-08-05 13:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:42:07 --> Language Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Loader Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:42:07 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:42:07 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Session Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:42:07 --> Session routines successfully run
DEBUG - 2013-08-05 13:42:07 --> Controller Class Initialized
DEBUG - 2013-08-05 13:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:42:07 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 13:42:07 --> Final output sent to browser
DEBUG - 2013-08-05 13:42:07 --> Total execution time: 0.5612
DEBUG - 2013-08-05 13:42:24 --> Config Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Hooks Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Utf8 Class Initialized
DEBUG - 2013-08-05 13:42:24 --> UTF-8 Support Enabled
DEBUG - 2013-08-05 13:42:24 --> URI Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Router Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Output Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Security Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Input Class Initialized
DEBUG - 2013-08-05 13:42:24 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:24 --> XSS Filtering completed
DEBUG - 2013-08-05 13:42:24 --> CRSF cookie Set
DEBUG - 2013-08-05 13:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-08-05 13:42:24 --> Language Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Loader Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Helper loaded: url_helper
DEBUG - 2013-08-05 13:42:24 --> Helper loaded: form_helper
DEBUG - 2013-08-05 13:42:24 --> Database Driver Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Session Class Initialized
DEBUG - 2013-08-05 13:42:24 --> Helper loaded: string_helper
DEBUG - 2013-08-05 13:42:25 --> Session routines successfully run
DEBUG - 2013-08-05 13:42:25 --> Controller Class Initialized
DEBUG - 2013-08-05 13:42:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-08-05 13:42:25 --> File loaded: application/views/teacher/grade.php
DEBUG - 2013-08-05 13:42:25 --> Final output sent to browser
DEBUG - 2013-08-05 13:42:25 --> Total execution time: 0.5605

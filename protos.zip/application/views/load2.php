<!doctype html>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="3; URL=<?php echo site_url('teacher/classes');?>"> 
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="loading.css">

</head>

<body style="background:url('<?php echo base_url() . 'assets/img/loader_full.gif';?>') no-repeat top center">

<div id="loadingimg">
	<!-- <img src="<?php echo base_url() ?>/assets/img/loader_full.gif"> -->
</div>


</body>
</html>

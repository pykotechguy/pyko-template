<!doctype html>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="3; URL=<?php echo site_url('teacher/class');?>"> 
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/loading.css">

</head>

<body>

<div id="loadingimg">
	<img src="<?php echo base_url() ?>/assets/img/loader_full.gif">
</div>


</body>
</html>
